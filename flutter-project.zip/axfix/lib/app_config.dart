// ═══════════════════════════════════════════════════════════════
// APP CONFIG — SATU TEMPAT UNTUK DOMAIN & PORT
// Ganti di sini saja, semua file langsung update otomatis
// ═══════════════════════════════════════════════════════════════

const String kDomain = 'http://serverku.lynzzofficial.com';
const int    kPort   = 2472;

/// Base URL siap pakai — gunakan ini di seluruh app
const String kBaseUrl = 'http://serverku.lynzzofficial.com:2472';
