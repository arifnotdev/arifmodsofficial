import 'app_config.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dashboard_page.dart';
import 'splash.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with SingleTickerProviderStateMixin {

  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _formKey  = GlobalKey<FormState>();

  bool _loading = false;
  bool _obscure = true;
  String? _androidId;

  late AnimationController _animCtrl;
  late Animation<double>   _fadeAnim;
  late Animation<Offset>   _slideAnim;

  static const _bg1     = Color(0xFF0D0000);
  static const _bg2     = Color(0xFF1A0000);
  static const _card    = Color(0xFF200000);
  static const _brd     = Color(0xFF660000);
  static const _accent  = Color(0xFFCC0000);
  static const _accentL = Color(0xFFFF5252);
  static const _txt     = Color(0xFFFFEEEE);
  static const _txtSub  = Color(0xFFFF8A80);

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..forward();
    _fadeAnim  = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic));
    _initLogin();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _userCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<String> _getAndroidId() async {
    try {
      final di = DeviceInfoPlugin();
      final info = await di.androidInfo;
      return '${info.brand}-${info.model}-${info.id}'.replaceAll(' ', '_');
    } catch (_) { return 'unknown_device'; }
  }

  Future<void> _initLogin() async {
    _androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey  = prefs.getString('key');
    if (savedUser != null && savedPass != null && savedKey != null) {
      try {
        final res = await http.get(Uri.parse(
          '$kBaseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$_androidId&key=$savedKey'))
          .timeout(const Duration(seconds: 10));
        final d = jsonDecode(res.body);
        if (d['valid'] == true && mounted) {
          _navDashboard(d);
          return;
        }
      } catch (_) {}
    }
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final res = await http.post(
        Uri.parse('$kBaseUrl/validate'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'username': _userCtrl.text.trim(),
          'password': _passCtrl.text.trim(),
          'androidId': _androidId ?? 'unknown',
        },
      ).timeout(const Duration(seconds: 15));

      final d = jsonDecode(res.body);
      if (!mounted) return;

      if (d['expired'] == true) {
        _showPopup('Access Expired', 'Akses kamu sudah habis. Hubungi admin.', Colors.orange);
      } else if (d['valid'] != true) {
        _showPopup('Login Gagal', 'Username atau password salah.', Colors.red);
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', _userCtrl.text.trim());
        prefs.setString('password', _passCtrl.text.trim());
        prefs.setString('key', d['key'] ?? '');
        _navDashboard(d);
      }
    } catch (e) {
      String msg = 'Gagal konek ke server. Cek koneksi internet.';
      if (e.toString().contains('timeout')) msg = 'Server timeout. Coba lagi.';
      _showPopup('Error', msg, Colors.orange);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _navDashboard(Map d) {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) =>
      SplashScreen(
        username: d['username'] ?? '',
        password: d['password'] ?? '',
        role: d['role'] ?? 'member',
        sessionKey: d['key'] ?? '',
        expiredDate: d['expiredDate'] ?? '',
        listBug: List<Map<String, dynamic>>.from(
          (d['listBug'] ?? []).map((e) => Map<String, dynamic>.from(e is Map ? e : {}))),
        listDoos: List<Map<String, dynamic>>.from(
          (d['listDoos'] ?? []).map((e) => Map<String, dynamic>.from(e is Map ? e : {}))),
        news: List<dynamic>.from(d['news'] ?? []),
      )));
  }

  void _showPopup(String title, String msg, Color color) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: _brd)),
      title: Row(children: [
        Icon(Icons.warning_rounded, color: color, size: 20),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(color: _txt, fontSize: 15, fontWeight: FontWeight.bold)),
      ]),
      content: Text(msg, style: const TextStyle(color: _txtSub, fontSize: 13)),
      actions: [TextButton(onPressed: () => Navigator.pop(context),
        child: const Text('OK', style: TextStyle(color: _accentL, fontWeight: FontWeight.bold)))],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: _bg1,
      // Biar keyboard tidak push content
      resizeToAvoidBottomInset: true,
      body: Stack(children: [

        // Grid background
        CustomPaint(size: size, painter: _GridPainter()),

        // Glow atas
        Positioned(top: -80, left: size.width / 2 - 150,
          child: Container(width: 300, height: 300,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: RadialGradient(colors: [_accent.withOpacity(0.2), Colors.transparent])))),

        // ── Layout: logo/title di atas, form di bawah setengah layar ─────
        SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Column(
              children: [

                // ── Bagian atas: logo + title ─────────────────────────────
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: SlideTransition(
                      position: _slideAnim,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Icon / Logo
                          Container(
                            width: 72, height: 72,
                            decoration: BoxDecoration(
                              color: _bg2,
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(color: _brd, width: 1.5),
                              boxShadow: [BoxShadow(color: _accent.withOpacity(0.3), blurRadius: 20)],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: Image.asset('assets/images/icon.jpg', fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(Icons.security_rounded, color: _accentL, size: 36)),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // SYSTEM GATEWAY label
                          Text('SYSTEM GATEWAY', style: TextStyle(
                            color: _accentL.withOpacity(0.7), fontSize: 11,
                            letterSpacing: 3, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 8),

                          // Title
                          const Text('VILLAIN',
                            style: TextStyle(color: _txt, fontSize: 40, fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron', letterSpacing: 2,
                              shadows: [Shadow(color: _accentL, blurRadius: 20)])),
                          const SizedBox(height: 8),

                          const Text('Otentikasi kredensial untuk melanjutkan akses.',
                            style: TextStyle(color: _txtSub, fontSize: 13, height: 1.4)),
                        ],
                      ),
                    ),
                  ),
                ),

                // ── Bagian bawah: form login (setengah layar bawah) ───────
                SlideTransition(
                  position: _slideAnim,
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: _card,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(32),
                        topRight: Radius.circular(32),
                      ),
                      border: Border.all(color: _brd, width: 1),
                      boxShadow: [BoxShadow(color: _accent.withOpacity(0.2), blurRadius: 30, offset: const Offset(0, -5))],
                    ),
                    padding: const EdgeInsets.fromLTRB(24, 32, 24, 32),
                    child: SingleChildScrollView(
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Header form
                            const Text('Login', style: TextStyle(
                              color: _txt, fontSize: 20, fontWeight: FontWeight.w900,
                              letterSpacing: 1)),
                            const SizedBox(height: 4),
                            Text('Masukkan kredensial kamu', style: TextStyle(
                              color: _txtSub.withOpacity(0.7), fontSize: 12)),
                            const SizedBox(height: 24),

                            // Username
                            _field(
                              ctrl: _userCtrl,
                              hint: 'Username',
                              prefix: const Icon(Icons.person_outline_rounded, color: _txtSub, size: 22),
                              validator: (v) => v == null || v.isEmpty ? 'Masukkan username' : null,
                            ),
                            const SizedBox(height: 14),

                            // Password
                            _field(
                              ctrl: _passCtrl,
                              hint: 'Password',
                              obscure: _obscure,
                              prefix: const Icon(Icons.lock_outline_rounded, color: _txtSub, size: 22),
                              suffix: GestureDetector(
                                onTap: () => setState(() => _obscure = !_obscure),
                                child: Icon(
                                  _obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                                  color: _txtSub, size: 20,
                                ),
                              ),
                              validator: (v) => v == null || v.isEmpty ? 'Masukkan password' : null,
                            ),
                            const SizedBox(height: 24),

                            // AUTHORIZE button
                            SizedBox(
                              width: double.infinity,
                              height: 54,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  padding: EdgeInsets.zero,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                ),
                                onPressed: _loading ? null : _login,
                                child: Ink(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: _loading
                                          ? [_brd, _brd]
                                          : [_accent, const Color(0xFF800000)],
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                    ),
                                    borderRadius: BorderRadius.circular(14),
                                    boxShadow: _loading
                                        ? []
                                        : [BoxShadow(color: _accent.withOpacity(0.5), blurRadius: 20, offset: const Offset(0, 6))],
                                  ),
                                  child: Center(
                                    child: _loading
                                        ? const SizedBox(
                                            width: 22, height: 22,
                                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                                          )
                                        : const Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(Icons.fingerprint_rounded, color: Colors.white, size: 22),
                                              SizedBox(width: 10),
                                              Text('AUTHORIZE', style: TextStyle(
                                                color: Colors.white, fontSize: 15,
                                                fontWeight: FontWeight.w900, letterSpacing: 2)),
                                            ],
                                          ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),

                            // Beli lisensi
                            Center(
                              child: GestureDetector(
                                onTap: () async {
                                  final uri = Uri.parse('https://t.me/ndraycaa');
                                  if (await canLaunchUrl(uri)) launchUrl(uri, mode: LaunchMode.externalApplication);
                                },
                                child: RichText(text: const TextSpan(children: [
                                  TextSpan(text: 'Belum punya lisensi? ',
                                    style: TextStyle(color: _txtSub, fontSize: 13)),
                                  TextSpan(text: 'Beli Disini',
                                    style: TextStyle(color: _accentL, fontSize: 13,
                                      fontWeight: FontWeight.bold, decoration: TextDecoration.underline)),
                                ])),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }

  Widget _field({
    required TextEditingController ctrl,
    required String hint,
    bool obscure = false,
    Widget? prefix,
    Widget? suffix,
    String? Function(String?)? validator,
  }) => TextFormField(
    controller: ctrl,
    obscureText: obscure,
    style: const TextStyle(color: _txt, fontSize: 14),
    validator: validator,
    decoration: InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: _txtSub, fontSize: 13),
      prefixIcon: prefix != null ? Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: prefix) : null,
      prefixIconConstraints: const BoxConstraints(minWidth: 50),
      suffixIcon: suffix != null ? Padding(padding: const EdgeInsets.only(right: 14), child: suffix) : null,
      filled: true,
      fillColor: _bg2,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _brd)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _brd)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _accentL, width: 1.5)),
      errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Colors.red)),
      focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Colors.red)),
      errorStyle: const TextStyle(color: Colors.redAccent, fontSize: 11),
    ));
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF3D0000).withOpacity(0.6)
      ..strokeWidth = 0.5;
    const spacing = 30.0;
    for (double x = 0; x <= size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override bool shouldRepaint(_GridPainter _) => false;
}
