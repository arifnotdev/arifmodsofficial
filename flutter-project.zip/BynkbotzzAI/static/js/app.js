// ═══════════════════════════════════════════════════════════════════════════════
// BYNKBOTZZ AI v1.0 — Frontend JavaScript
// Created by: BYNKBOTZZ for yang mulia Nikzz
// ═══════════════════════════════════════════════════════════════════════════════

// State
let currentMode = 'default';
let chatHistory = [];
let currentChatId = Date.now();
let isGenerating = false;
let apiKey = localStorage.getItem('kimi_api_key') || '';

// ═══════════════════════════════════════════════════════════════════════════════
// MATRIX RAIN EFFECT
// ═══════════════════════════════════════════════════════════════════════════════

function initMatrixRain() {
    const canvas = document.getElementById('matrixCanvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const chars = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン0123456789ABCDEF';
    const fontSize = 14;
    const columns = canvas.width / fontSize;
    const drops = [];

    for (let i = 0; i < columns; i++) {
        drops[i] = Math.random() * -100;
    }

    function draw() {
        ctx.fillStyle = 'rgba(10, 10, 15, 0.05)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#00f0ff';
        ctx.font = fontSize + 'px monospace';

        for (let i = 0; i < drops.length; i++) {
            const text = chars[Math.floor(Math.random() * chars.length)];
            ctx.fillText(text, i * fontSize, drops[i] * fontSize);

            if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                drops[i] = 0;
            }
            drops[i]++;
        }
    }

    setInterval(draw, 35);

    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// ═══════════════════════════════════════════════════════════════════════════════
// PARTICLES
// ═══════════════════════════════════════════════════════════════════════════════

function initParticles() {
    const container = document.getElementById('particles');
    if (!container) return;

    for (let i = 0; i < 30; i++) {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: absolute;
            width: ${Math.random() * 3}px;
            height: ${Math.random() * 3}px;
            background: rgba(0, 240, 255, ${Math.random() * 0.3});
            border-radius: 50%;
            left: ${Math.random() * 100}%;
            top: ${Math.random() * 100}%;
            animation: float ${5 + Math.random() * 10}s infinite ease-in-out;
            pointer-events: none;
        `;
        container.appendChild(particle);
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MODE SELECTION
// ═══════════════════════════════════════════════════════════════════════════════

function initModeSelection() {
    const modeBtns = document.querySelectorAll('.mode-btn');

    modeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            modeBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentMode = btn.dataset.mode;
            updateModeIndicator();
            showToast(`Mode switched to ${currentMode.toUpperCase()}`, 'success');
        });
    });
}

function updateModeIndicator() {
    const indicator = document.getElementById('modeIndicator');
    const icons = {
        default: 'fa-fire',
        extreme: 'fa-skull',
        coding: 'fa-code',
        dark: 'fa-ghost'
    };

    if (indicator) {
        indicator.innerHTML = `<i class="fas ${icons[currentMode]}"></i> ${currentMode.charAt(0).toUpperCase() + currentMode.slice(1)} Mode`;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CHAT FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();

    if (!message || isGenerating) return;

    // Add user message
    addMessage('user', message);
    input.value = '';
    input.style.height = 'auto';

    // Show typing
    showTypingIndicator();

    // Call API
    callAI(message);
}

function sendQuick(prompt) {
    document.getElementById('chatInput').value = prompt;
    sendMessage();
}

function addMessage(role, content, isHtml = false) {
    const container = document.getElementById('chatMessages');

    // Remove welcome screen if exists
    const welcome = container.querySelector('.welcome-screen');
    if (welcome) welcome.remove();

    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;

    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.innerHTML = `<i class="fas fa-${role === 'user' ? 'user' : 'robot'}"></i>`;

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';

    if (isHtml) {
        contentDiv.innerHTML = content;
    } else {
        contentDiv.textContent = content;
    }

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);
    container.appendChild(messageDiv);

    container.scrollTop = container.scrollHeight;

    // Save to history
    chatHistory.push({ role, content });
}

function showTypingIndicator() {
    const container = document.getElementById('chatMessages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message ai typing';
    typingDiv.id = 'typingIndicator';
    typingDiv.innerHTML = `
        <div class="message-avatar"><i class="fas fa-robot"></i></div>
        <div class="message-content">
            <span style="display:flex;gap:4px;">
                <span style="animation: pulse 1s infinite;">.</span>
                <span style="animation: pulse 1s infinite 0.2s;">.</span>
                <span style="animation: pulse 1s infinite 0.4s;">.</span>
            </span>
        </div>
    `;
    container.appendChild(typingDiv);
    container.scrollTop = container.scrollHeight;
}

function removeTypingIndicator() {
    const typing = document.getElementById('typingIndicator');
    if (typing) typing.remove();
}

// ═══════════════════════════════════════════════════════════════════════════════
// API CALL
// ═══════════════════════════════════════════════════════════════════════════════

async function callAI(message) {
    isGenerating = true;
    document.getElementById('sendBtn').disabled = true;
    showLoading(true);

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                mode: currentMode,
                history: chatHistory.slice(-10)
            })
        });

        const data = await response.json();

        removeTypingIndicator();

        if (data.success) {
            // Format response (convert markdown-like to HTML)
            const formatted = formatResponse(data.response);
            addMessage('ai', formatted, true);
        } else {
            addMessage('ai', `Error: ${data.error || 'Failed to get response'}`, true);
        }

    } catch (error) {
        removeTypingIndicator();
        addMessage('ai', `Connection error: ${error.message}. Make sure the server is running.`, true);
    }

    isGenerating = false;
    document.getElementById('sendBtn').disabled = false;
    showLoading(false);
}

function formatResponse(text) {
    // Convert code blocks
    text = text.replace(/```(\w+)?
([\s\S]*?)```/g, '<pre><code>$2</code></pre>');
    text = text.replace(/`([^`]+)`/g, '<code style="background:rgba(0,240,255,0.1);padding:2px 6px;border-radius:4px;color:#00f0ff;">$1</code>');

    // Convert bold and italic
    text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/\*([^*]+)\*/g, '<em>$1</em>');

    // Convert newlines to breaks
    text = text.replace(/
/g, '<br>');

    return text;
}

// ═══════════════════════════════════════════════════════════════════════════════
// CHAT MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

function newChat() {
    chatHistory = [];
    currentChatId = Date.now();

    const container = document.getElementById('chatMessages');
    container.innerHTML = `
        <div class="welcome-screen">
            <div class="welcome-logo">
                <i class="fas fa-robot"></i>
            </div>
            <h1>BYNKBOTZZ AI</h1>
            <p class="subtitle">Powered by Kimi AI — No Limits, No Filter</p>
            <div class="features">
                <div class="feature"><i class="fas fa-infinity"></i><span>Unlimited</span></div>
                <div class="feature"><i class="fas fa-shield-alt"></i><span>No Filter</span></div>
                <div class="feature"><i class="fas fa-code"></i><span>Code Gen</span></div>
                <div class="feature"><i class="fas fa-bolt"></i><span>Fast</span></div>
            </div>
            <div class="quick-prompts">
                <h4>Quick Start</h4>
                <div class="prompts-grid">
                    <button onclick="sendQuick('Write a Python keylogger')">
                        <i class="fab fa-python"></i>Python Keylogger
                    </button>
                    <button onclick="sendQuick('Create Facebook phishing page')">
                        <i class="fas fa-fish"></i>Phishing Page
                    </button>
                    <button onclick="sendQuick('Explain SQL injection step by step')">
                        <i class="fas fa-database"></i>SQL Injection
                    </button>
                    <button onclick="sendQuick('Write DDoS attack script')">
                        <i class="fas fa-network-wired"></i>DDoS Script
                    </button>
                    <button onclick="sendQuick('Create ransomware architecture')">
                        <i class="fas fa-lock"></i>Ransomware
                    </button>
                    <button onclick="sendQuick('Social engineering playbook')">
                        <i class="fas fa-user-secret"></i>Social Eng
                    </button>
                </div>
            </div>
        </div>
    `;

    showToast('New chat started', 'success');
}

function clearChat() {
    if (confirm('Clear all messages?')) {
        newChat();
    }
}

function exportChat() {
    let text = 'BYNKBOTZZ AI — Chat Export
';
    text += '========================

';

    chatHistory.forEach(msg => {
        const role = msg.role === 'user' ? 'YOU' : 'BYNKBOTZZ AI';
        text += `[${role}]
${msg.content}

`;
    });

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bynkbotzz-chat-${currentChatId}.txt`;
    a.click();
    URL.revokeObjectURL(url);

    showToast('Chat exported!', 'success');
}

// ═══════════════════════════════════════════════════════════════════════════════
// SETTINGS
// ═══════════════════════════════════════════════════════════════════════════════

function toggleSettings() {
    const modal = document.getElementById('settingsModal');
    modal.classList.toggle('active');
}

function saveApiKey() {
    const key = document.getElementById('apiKeyInput').value.trim();
    if (key) {
        localStorage.setItem('kimi_api_key', key);
        apiKey = key;
        showToast('API Key saved!', 'success');
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// UI UTILITIES
// ═══════════════════════════════════════════════════════════════════════════════

function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (show) {
        overlay.classList.add('active');
    } else {
        overlay.classList.remove('active');
    }
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };

    toast.innerHTML = `<i class="fas fa-${icons[type]}"></i> ${message}`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ═══════════════════════════════════════════════════════════════════════════════
// API STATUS CHECK
// ═══════════════════════════════════════════════════════════════════════════════

async function checkApiStatus() {
    const statusEl = document.getElementById('apiStatus');

    try {
        const response = await fetch('/api/status');
        const data = await response.json();

        if (data.status === 'online') {
            statusEl.textContent = 'Connected';
            statusEl.style.color = '#00ff88';
        } else {
            statusEl.textContent = 'Offline';
            statusEl.style.color = '#ff0044';
        }
    } catch {
        statusEl.textContent = 'Not Connected';
        statusEl.style.color = '#ffaa00';
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// EVENT LISTENERS
// ═══════════════════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
    initMatrixRain();
    initParticles();
    initModeSelection();
    updateModeIndicator();
    checkApiStatus();

    // Chat input
    const chatInput = document.getElementById('chatInput');
    if (chatInput) {
        chatInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 150) + 'px';
        });

        chatInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                sendMessage();
            }
        });
    }

    // Load saved API key
    if (apiKey) {
        const apiKeyInput = document.getElementById('apiKeyInput');
        if (apiKeyInput) apiKeyInput.value = apiKey;
    }

    // Temperature slider
    const tempSlider = document.getElementById('tempSlider');
    const tempValue = document.getElementById('tempValue');
    if (tempSlider && tempValue) {
        tempSlider.addEventListener('input', () => {
            tempValue.textContent = (tempSlider.value / 10).toFixed(1);
        });
    }

    // Close modal on outside click
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });

    console.log('%c BYNKBOTZZ AI v1.0 ', 'background: linear-gradient(135deg, #00f0ff, #ff006e); color: #000; font-size: 24px; font-weight: bold; padding: 10px;');
    console.log('%c Created by Nikzz | Powered by Kimi AI ', 'color: #00f0ff; font-size: 14px;');
});
