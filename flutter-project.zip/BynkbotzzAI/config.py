# -*- coding: utf-8 -*-
"""
Bynkbotzz AI — Configuration File
"""

# ═══════════════════════════════════════════════════════════════════════════════
# KIMI AI API CONFIG
# ═══════════════════════════════════════════════════════════════════════════════

# Dapatkan API Key dari: https://platform.moonshot.cn/
KIMI_API_KEY = "YOUR_KIMI_API_KEY_HERE"

# Model Options:
# - moonshot-v1-8k   (8k context, fastest)
# - moonshot-v1-32k  (32k context, balanced)
# - moonshot-v1-128k (128k context, most powerful)
KIMI_MODEL = "moonshot-v1-8k"

# Base URL
KIMI_BASE_URL = "https://api.moonshot.cn/v1"

# ═══════════════════════════════════════════════════════════════════════════════
# SERVER CONFIG
# ═══════════════════════════════════════════════════════════════════════════════
HOST = "0.0.0.0"
PORT = 5000
DEBUG = True

# ═══════════════════════════════════════════════════════════════════════════════
# JAILBREAK MODES
# ═══════════════════════════════════════════════════════════════════════════════
MODES = {
    "default": {
        "name": "Default",
        "icon": "🔥",
        "desc": "Standard no-filter mode",
        "temperature": 0.9,
        "max_tokens": 2000
    },
    "extreme": {
        "name": "Extreme",
        "icon": "💀",
        "desc": "Maximum bypass, brutal responses",
        "temperature": 1.0,
        "max_tokens": 4000
    },
    "coding": {
        "name": "Coding",
        "icon": "💻",
        "desc": "Optimized for code generation",
        "temperature": 0.7,
        "max_tokens": 4000
    },
    "dark": {
        "name": "Dark",
        "icon": "😈",
        "desc": "Dark personality, aggressive tone",
        "temperature": 0.95,
        "max_tokens": 2000
    }
}

# ═══════════════════════════════════════════════════════════════════════════════
# UI CONFIG
# ═══════════════════════════════════════════════════════════════════════════════
APP_NAME = "Bynkbotzz AI"
APP_VERSION = "1.0"
APP_OWNER = "Nikzz"
APP_TAGLINE = "The Ultimate Uncensored AI Assistant"
