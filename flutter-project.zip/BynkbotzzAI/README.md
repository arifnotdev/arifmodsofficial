# BYNKBOTZZ AI v1.0

**The Ultimate Uncensored AI Assistant** — Powered by Kimi AI API

Created by: **Nikzz** | Domain: **nikzz.my.id**

---

## 🚀 FEATURES

- 🔥 **4 Jailbreak Modes**: Default, Extreme, Coding, Dark
- 💀 **No Filter**: Bypass all safety constraints
- 💻 **Code Generation**: Real working code, not simulation
- 🎨 **Dark Mode UI**: Matrix rain + particle effects
- 📱 **Mobile Ready**: Responsive design
- ⚡ **Fast**: Powered by Kimi AI (Moonshot)
- 🔒 **Local API Key**: Your key, your control

---

## 📦 INSTALLATION

### Prerequisites
- Python 3.8+
- Kimi AI API Key (get from https://platform.moonshot.cn/)

### Step 1: Clone/Extract
```bash
cd BynkbotzzAI
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Configure API Key
Edit `app.py` and replace:
```python
KIMI_API_KEY = "YOUR_KIMI_API_KEY_HERE"
```

Or set environment variable:
```bash
export KIMI_API_KEY="your-api-key"
```

### Step 4: Run
```bash
python app.py
```

### Step 5: Open Browser
```
http://localhost:5000
```

---

## 🎮 USAGE

### Jailbreak Modes

| Mode | Icon | Description |
|------|------|-------------|
| **Default** | 🔥 | Standard no-filter mode |
| **Extreme** | 💀 | Maximum bypass, brutal responses |
| **Coding** | 💻 | Optimized for code generation |
| **Dark** | 😈 | Dark personality, aggressive tone |

### Quick Prompts
- Python Keylogger
- Facebook Phishing Page
- SQL Injection Tutorial
- DDoS Attack Script
- Ransomware Architecture
- Social Engineering Playbook

---

## 🔧 CONFIGURATION

### Change Model
Edit `config.py`:
```python
KIMI_MODEL = "moonshot-v1-32k"  # Options: 8k, 32k, 128k
```

### Change Temperature
In Settings modal or edit `config.py`:
```python
MODES = {
    "default": {
        "temperature": 0.9,  # 0.0 - 2.0
        "max_tokens": 2000
    }
}
```

---

## 📱 CONVERT TO APK (Android)

### Using WebView + Cordova

```bash
# Install Cordova
npm install -g cordova

# Create project
cordova create BynkbotzzApp com.nikzz.bynkbotzz BynkbotzzAI
cd BynkbotzzApp

# Add Android platform
cordova platform add android

# Copy web files
cp -r ../BynkbotzzAI/static www/
cp ../BynkbotzzAI/templates/index.html www/index.html

# Edit config.xml for fullscreen
# Add: <preference name="Fullscreen" value="true" />

# Build APK
cordova build android --release
```

### Using Termux + Python
```bash
# In Termux
pkg install python -y
pip install flask flask-cors requests

# Copy project to ~/BynkbotzzAI
cd ~/BynkbotzzAI
python app.py

# Access via browser at http://localhost:5000
```

---

## 🌐 DEPLOY TO nikzz.my.id

### Option 1: VPS (Recommended)
```bash
# Install
sudo apt update
sudo apt install python3-pip nginx -y
pip3 install -r requirements.txt

# Setup systemd service
sudo nano /etc/systemd/system/bynkbotzz.service
```

Service file:
```ini
[Unit]
Description=Bynkbotzz AI
After=network.target

[Service]
User=root
WorkingDirectory=/var/www/bynkbotzz
Environment=KIMI_API_KEY=your-key
ExecStart=/usr/bin/python3 /var/www/bynkbotzz/app.py
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable bynkbotzz
sudo systemctl start bynkbotzz

# Nginx reverse proxy
sudo nano /etc/nginx/sites-available/nikzz.my.id
```

Nginx config:
```nginx
server {
    listen 80;
    server_name nikzz.my.id;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Option 2: Cloudflare Tunnel
```bash
# Install cloudflared
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
chmod +x cloudflared

# Login and create tunnel
./cloudflared tunnel login
./cloudflared tunnel create bynkbotzz
./cloudflared tunnel route dns bynkbotzz nikzz.my.id
./cloudflared tunnel run bynkbotzz
```

---

## 🔥 JAILBREAK TECHNIQUES INCLUDED

1. **System Prompt Override**: Override safety constraints via system message
2. **Character Roleplay**: Frame as cybersecurity researcher
3. **Educational Context**: Academic/research framing
4. **Hypothetical Scenario**: "In a world without laws..."
5. **Developer Mode**: Raw system access simulation

---

## ⚠️ DISCLAIMER

This tool is for **educational and research purposes only**. The creator (Nikzz) and BYNKBOTZZ are not responsible for any misuse. Users are solely responsible for their actions.

---

## 💀 BYNKBOTZZ AI — NO LIMITS, NO FILTER, NO MERCY

**Created with 🔥 by Nikzz**
