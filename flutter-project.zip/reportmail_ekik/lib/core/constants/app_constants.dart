/// Konstanta bisnis & API sesuai spesifikasi ReportMail Ekik.
class AppConstants {
  AppConstants._();

  static const int maxSenderPerUser = 200;
  static const int targetPaginationSize = 50;

  static const List<int> batchSizeOptions = [25, 50, 100];
  static const int defaultBatchSize = 50;

  static const List<double> telegramDelayOptions = [0.5, 1, 2];
  static const double defaultTelegramDelay = 1;

  static const List<int> maxAttachmentMbOptions = [2, 5, 10];
  static const int defaultMaxAttachmentMb = 5;

  // GANTI sesuai environment (local dev / production server).
  static const String baseUrl = 'https://api.reportmail-ekik.test/api';

  static const String prefTokenKey = 'auth_token';
  static const String prefThemeKey = 'theme_mode';
}
