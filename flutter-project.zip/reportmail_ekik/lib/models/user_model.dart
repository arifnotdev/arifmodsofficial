class UserModel {
  final int id;
  final String username;
  final String role; // 'admin' | 'user'
  final bool isFirstLogin;

  UserModel({
    required this.id,
    required this.username,
    required this.role,
    required this.isFirstLogin,
  });

  bool get isAdmin => role == 'admin';

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      username: json['username'],
      role: json['role'],
      isFirstLogin: json['is_first_login'] ?? false,
    );
  }
}
