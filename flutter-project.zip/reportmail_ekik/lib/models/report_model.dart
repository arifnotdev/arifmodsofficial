class ReportModel {
  final int id;
  final String senderType; // 'email' | 'telegram'
  final String? subject;
  final int totalTargets;
  final int processedTargets;
  final int failedTargets;
  final String status; // pending | processing | completed | failed
  final DateTime createdAt;

  ReportModel({
    required this.id,
    required this.senderType,
    this.subject,
    required this.totalTargets,
    required this.processedTargets,
    required this.failedTargets,
    required this.status,
    required this.createdAt,
  });

  factory ReportModel.fromJson(Map<String, dynamic> json) {
    return ReportModel(
      id: json['id'],
      senderType: json['sender_type'],
      subject: json['subject'],
      totalTargets: json['total_targets'] ?? 0,
      processedTargets: json['processed_targets'] ?? 0,
      failedTargets: json['failed_targets'] ?? 0,
      status: json['status'] ?? 'pending',
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
    );
  }
}

class ReportRecipientModel {
  final int id;
  final String recipientAddress;
  final String status; // sent | failed | pending
  final String? errorMessage;

  ReportRecipientModel({
    required this.id,
    required this.recipientAddress,
    required this.status,
    this.errorMessage,
  });

  factory ReportRecipientModel.fromJson(Map<String, dynamic> json) {
    return ReportRecipientModel(
      id: json['id'],
      recipientAddress: json['recipient_address'],
      status: json['status'] ?? 'pending',
      errorMessage: json['error_message'],
    );
  }
}
