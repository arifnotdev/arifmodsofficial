class TargetEmailModel {
  final int id;
  final String email;
  final String? name;
  final String? category;

  TargetEmailModel({required this.id, required this.email, this.name, this.category});

  factory TargetEmailModel.fromJson(Map<String, dynamic> json) {
    return TargetEmailModel(
      id: json['id'],
      email: json['email'],
      name: json['name'],
      category: json['category'],
    );
  }
}

class TargetTelegramModel {
  final int id;
  final String chatId;
  final String? name;
  final String? category;

  TargetTelegramModel({required this.id, required this.chatId, this.name, this.category});

  factory TargetTelegramModel.fromJson(Map<String, dynamic> json) {
    return TargetTelegramModel(
      id: json['id'],
      chatId: json['chat_id'],
      name: json['name'],
      category: json['category'],
    );
  }
}
