import 'package:flutter/material.dart';
import '../core/constants/app_theme.dart';

/// Kartu statistik dashboard, opsional menampilkan progress bar (X/200).
class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final double? progress; // 0.0 - 1.0, null jika tidak perlu progress bar

  const StatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.progress,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spacingStandard),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: theme.colorScheme.secondary, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(label, style: theme.textTheme.labelSmall),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(value, style: theme.textTheme.titleLarge),
            if (progress != null) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: progress!.clamp(0, 1),
                  minHeight: 6,
                  backgroundColor: theme.colorScheme.secondary.withOpacity(0.15),
                  valueColor: AlwaysStoppedAnimation(theme.colorScheme.secondary),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
