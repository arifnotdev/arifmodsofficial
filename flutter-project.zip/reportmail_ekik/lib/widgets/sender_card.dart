import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';
import 'status_indicator.dart';

/// Kartu sender (Email/Telegram): Inisial Nama (lingkaran Navy),
/// Alamat/No HP (tebal), Host/Sesi (tipis), indikator status, ikon hapus.
class SenderCard extends StatelessWidget {
  final String title; // alamat email / no HP
  final String subtitle; // smtp host / session name
  final bool isActive;
  final VoidCallback onDelete;

  const SenderCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.isActive,
    required this.onDelete,
  });

  String get _initial => title.isNotEmpty ? title[0].toUpperCase() : '?';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: AppColors.primaryNavy,
              foregroundColor: Colors.white,
              child: Text(_initial, style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: theme.textTheme.labelSmall),
                ],
              ),
            ),
            StatusIndicator(
              status: isActive ? ReportStatus.sent : ReportStatus.inactive,
              size: 10,
            ),
            const SizedBox(width: 12),
            InkWell(
              onTap: onDelete,
              child: const Icon(Icons.delete_outline, color: AppColors.statusFailed, size: 20),
            ),
          ],
        ),
      ),
    );
  }
}
