import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_colors.dart';
import '../../models/target_model.dart';
import '../../providers/target_provider.dart';

/// Bottom sheet pemilihan target: search bar, list checkbox (pagination 50),
/// dan tombol "Pilih Semua" (teks Gold) sesuai spesifikasi section 10.E.
///
/// Mengembalikan: {selectAll: bool, ids: Set<int>}
class TargetPickerSheet extends ConsumerStatefulWidget {
  final bool isEmail;
  final Set<int> initialSelectedIds;
  final bool initialSelectAll;

  const TargetPickerSheet({
    super.key,
    required this.isEmail,
    required this.initialSelectedIds,
    required this.initialSelectAll,
  });

  @override
  ConsumerState<TargetPickerSheet> createState() => _TargetPickerSheetState();
}

class _TargetPickerSheetState extends ConsumerState<TargetPickerSheet> {
  late Set<int> _selectedIds;
  late bool _selectAll;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedIds = {...widget.initialSelectedIds};
    _selectAll = widget.initialSelectAll;
  }

  void _toggleSelectAll() {
    setState(() => _selectAll = !_selectAll);
    if (_selectAll) _selectedIds.clear();
  }

  @override
  Widget build(BuildContext context) {
    final emailState = ref.watch(targetEmailListProvider);
    final telegramState = ref.watch(targetTelegramListProvider);
    final emailController = ref.read(targetEmailListProvider.notifier);
    final telegramController = ref.read(targetTelegramListProvider.notifier);

    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Pilih Target', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchCtrl,
                      decoration: const InputDecoration(
                        hintText: 'Cari target...',
                        prefixIcon: Icon(Icons.search),
                      ),
                      onSubmitted: (val) {
                        if (widget.isEmail) {
                          emailController.load(search: val);
                        } else {
                          telegramController.load(search: val);
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  TextButton(
                    onPressed: _toggleSelectAll,
                    child: Text(
                      _selectAll ? 'Batal Pilih Semua' : 'Pilih Semua',
                      style: const TextStyle(color: AppColors.goldPremiumAlt, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              if (_selectAll)
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.goldPremium.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'Semua target akan dipilih (termasuk yang tidak tampil di halaman ini).',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
              const SizedBox(height: 8),
              Expanded(
                child: widget.isEmail
                    ? emailState.when(
                        loading: () => const Center(child: CircularProgressIndicator()),
                        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
                        data: (items) => _buildList<TargetEmailModel>(
                          scrollController,
                          items,
                          (t) => t.id,
                          (t) => t.email,
                          (t) => t.name,
                        ),
                      )
                    : telegramState.when(
                        loading: () => const Center(child: CircularProgressIndicator()),
                        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
                        data: (items) => _buildList<TargetTelegramModel>(
                          scrollController,
                          items,
                          (t) => t.id,
                          (t) => t.chatId,
                          (t) => t.name,
                        ),
                      ),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context, {
                    'selectAll': _selectAll,
                    'ids': _selectedIds,
                  });
                },
                child: Text(_selectAll
                    ? 'Gunakan Semua Target'
                    : 'Gunakan ${_selectedIds.length} Target Terpilih'),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildList<T>(
    ScrollController scrollController,
    List<T> items,
    int Function(T) idOf,
    String Function(T) titleOf,
    String? Function(T) subtitleOf,
  ) {
    if (items.isEmpty) {
      return const Center(child: Text('Tidak ada target.'));
    }

    return ListView.builder(
      controller: scrollController,
      itemCount: items.length,
      itemBuilder: (ctx, i) {
        final item = items[i];
        final id = idOf(item);
        final checked = _selectAll || _selectedIds.contains(id);

        return CheckboxListTile(
          value: checked,
          enabled: !_selectAll,
          activeColor: AppColors.goldPremium,
          title: Text(titleOf(item)),
          subtitle: subtitleOf(item) != null ? Text(subtitleOf(item)!) : null,
          onChanged: (val) {
            setState(() {
              if (val == true) {
                _selectedIds.add(id);
              } else {
                _selectedIds.remove(id);
              }
            });
          },
        );
      },
    );
  }
}
