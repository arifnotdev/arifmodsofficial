import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/sender_provider.dart';
import '../../services/sender_service.dart';
import '../../widgets/quota_chip.dart';
import '../../widgets/sender_card.dart';

class SenderTelegramScreen extends ConsumerWidget {
  const SenderTelegramScreen({super.key});

  void _showAddFlow(BuildContext context, WidgetRef ref) {
    final sessionNameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 20 + MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Tambah Sender Telegram', style: Theme.of(ctx).textTheme.headlineSmall),
              const SizedBox(height: 16),
              TextField(controller: sessionNameCtrl, decoration: const InputDecoration(labelText: 'Nama Sesi')),
              const SizedBox(height: 12),
              TextField(
                controller: phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Nomor HP (format internasional, contoh +62812xxxx)'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  try {
                    final phoneCodeHash = await ref
                        .read(senderServiceProvider)
                        .initTelegramLogin(sessionNameCtrl.text, phoneCtrl.text);

                    if (ctx.mounted) {
                      Navigator.pop(ctx);
                      _showOtpDialog(context, ref, phoneCtrl.text, phoneCodeHash);
                    }
                  } on SenderLimitException catch (e) {
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(e.message)));
                    }
                  } catch (_) {
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(ctx).showSnackBar(
                        const SnackBar(content: Text('Gagal mengirim OTP. Periksa nomor HP.')),
                      );
                    }
                  }
                },
                child: const Text('Kirim Kode OTP'),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showOtpDialog(BuildContext context, WidgetRef ref, String phoneNumber, String phoneCodeHash) {
    final otpCtrl = TextEditingController();
    final twoFaCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Verifikasi OTP'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: otpCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Kode OTP dari Telegram'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: twoFaCtrl,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password 2FA (jika ada)'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () async {
              try {
                await ref.read(senderServiceProvider).verifyTelegramLogin(
                      phoneNumber: phoneNumber,
                      otpCode: otpCtrl.text,
                      phoneCodeHash: phoneCodeHash,
                      password2fa: twoFaCtrl.text.isEmpty ? null : twoFaCtrl.text,
                    );
                ref.read(senderTelegramListProvider.notifier).load();
                if (ctx.mounted) Navigator.pop(ctx);
              } catch (_) {
                if (ctx.mounted) {
                  ScaffoldMessenger.of(ctx).showSnackBar(
                    const SnackBar(content: Text('Kode OTP salah atau kedaluwarsa.')),
                  );
                }
              }
            },
            child: const Text('Verifikasi'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(senderTelegramListProvider);
    final controller = ref.read(senderTelegramListProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('Sender Telegram')),
      body: state.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Gagal memuat data: $e')),
        data: (senders) {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Align(alignment: Alignment.centerLeft, child: QuotaChip(current: senders.length)),
              ),
              Expanded(
                child: senders.isEmpty
                    ? const Center(child: Text('Belum ada sender telegram.'))
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: senders.length,
                        itemBuilder: (ctx, i) {
                          final s = senders[i];
                          return SenderCard(
                            title: s.phoneNumber,
                            subtitle: s.sessionName,
                            isActive: s.isActive,
                            onDelete: () => controller.remove(s.id),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: controller.isQuotaFull
          ? null
          : FloatingActionButton(
              onPressed: () => _showAddFlow(context, ref),
              child: const Icon(Icons.add),
            ),
    );
  }
}
