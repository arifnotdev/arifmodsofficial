import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/target_model.dart';
import '../services/target_service.dart';

final targetServiceProvider = Provider((ref) => TargetService());

class TargetEmailListController extends StateNotifier<AsyncValue<List<TargetEmailModel>>> {
  final TargetService _service;
  int currentPage = 1;
  int lastPage = 1;

  TargetEmailListController(this._service) : super(const AsyncValue.loading()) {
    load();
  }

  Future<void> load({int page = 1, String? search}) async {
    state = const AsyncValue.loading();
    try {
      final result = await _service.listEmailTargets(page: page, search: search);
      currentPage = result.currentPage;
      lastPage = result.lastPage;
      state = AsyncValue.data(result.items);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> remove(int id) async {
    await _service.deleteEmailTarget(id);
    await load(page: currentPage);
  }
}

final targetEmailListProvider =
    StateNotifierProvider<TargetEmailListController, AsyncValue<List<TargetEmailModel>>>((ref) {
  return TargetEmailListController(ref.read(targetServiceProvider));
});

class TargetTelegramListController extends StateNotifier<AsyncValue<List<TargetTelegramModel>>> {
  final TargetService _service;
  int currentPage = 1;
  int lastPage = 1;

  TargetTelegramListController(this._service) : super(const AsyncValue.loading()) {
    load();
  }

  Future<void> load({int page = 1, String? search}) async {
    state = const AsyncValue.loading();
    try {
      final result = await _service.listTelegramTargets(page: page, search: search);
      currentPage = result.currentPage;
      lastPage = result.lastPage;
      state = AsyncValue.data(result.items);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> remove(int id) async {
    await _service.deleteTelegramTarget(id);
    await load(page: currentPage);
  }
}

final targetTelegramListProvider =
    StateNotifierProvider<TargetTelegramListController, AsyncValue<List<TargetTelegramModel>>>((ref) {
  return TargetTelegramListController(ref.read(targetServiceProvider));
});
