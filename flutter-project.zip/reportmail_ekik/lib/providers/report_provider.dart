import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/report_model.dart';
import '../services/report_service.dart';

final reportServiceProvider = Provider((ref) => ReportService());

class ReportLogController extends StateNotifier<AsyncValue<List<ReportModel>>> {
  final ReportService _service;
  ReportLogController(this._service) : super(const AsyncValue.loading()) {
    load();
  }

  Future<void> load({int page = 1}) async {
    state = const AsyncValue.loading();
    try {
      final list = await _service.listReports(page: page);
      state = AsyncValue.data(list);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}

final reportLogProvider = StateNotifierProvider<ReportLogController, AsyncValue<List<ReportModel>>>((ref) {
  return ReportLogController(ref.read(reportServiceProvider));
});
