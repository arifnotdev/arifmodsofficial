import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/admin_service.dart';

final adminServiceProvider = Provider((ref) => AdminService());

class AdminUserListController extends StateNotifier<AsyncValue<List<AdminUserSummary>>> {
  final AdminService _service;
  AdminUserListController(this._service) : super(const AsyncValue.loading()) {
    load();
  }

  Future<void> load() async {
    state = const AsyncValue.loading();
    try {
      final list = await _service.listUsers();
      state = AsyncValue.data(list);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> deleteUser(int id) async {
    await _service.deleteUser(id);
    await load();
  }
}

final adminUserListProvider =
    StateNotifierProvider<AdminUserListController, AsyncValue<List<AdminUserSummary>>>((ref) {
  return AdminUserListController(ref.read(adminServiceProvider));
});
