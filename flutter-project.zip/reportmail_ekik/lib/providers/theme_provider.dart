import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants/app_constants.dart';

/// Mengelola mode tema (system/light/dark), disimpan lokal dan disinkron
/// ke user_settings backend lewat SettingsController (lihat settings_provider.dart).
class ThemeModeController extends StateNotifier<ThemeMode> {
  ThemeModeController() : super(ThemeMode.system) {
    _loadFromPrefs();
  }

  Future<void> _loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(AppConstants.prefThemeKey);
    state = _fromString(saved);
  }

  Future<void> setThemeMode(String mode) async {
    state = _fromString(mode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.prefThemeKey, mode);
  }

  ThemeMode _fromString(String? mode) {
    switch (mode) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }
}

final themeModeProvider = StateNotifierProvider<ThemeModeController, ThemeMode>((ref) {
  return ThemeModeController();
});
