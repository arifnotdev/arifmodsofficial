# ReportMail Ekik — Frontend (Flutter)

Aplikasi mobile Android untuk blast laporan via Email & Telegram.

## 1. Kebutuhan Sistem

- Flutter SDK >= 3.22 (Dart >= 3.3)
- Android Studio / VS Code dengan plugin Flutter
- Backend Laravel (lihat repo `reportmail-backend`) sudah berjalan & dapat diakses

## 2. Instalasi

```bash
cd reportmail_ekik

# 1. Install dependency
flutter pub get

# 2. Atur Base URL backend
# Edit file: lib/core/constants/app_constants.dart
# Ganti baseUrl ke alamat server Laravel kamu, contoh:
# static const String baseUrl = 'https://api.domainkamu.com/api';
# (Untuk testing di emulator + backend lokal, gunakan: http://10.0.2.2:8000/api)

# 3. Jalankan di device/emulator
flutter run
```

## 3. Build APK

```bash
flutter build apk --release
```

Hasil APK ada di:

```
build/app/outputs/flutter-apk/app-release.apk
```

Install ke HP via USB debugging, atau kirim file APK-nya langsung.

## 4. Struktur Folder

```
lib/
  core/
    constants/      -> app_colors.dart, app_theme.dart, app_constants.dart
    network/         -> dio_client.dart (interceptor token Bearer)
  models/            -> data class (User, Sender, Target, Report, Settings)
  services/          -> pemanggilan REST API per fitur
  providers/         -> Riverpod StateNotifier (auth, theme, sender, target, report, settings, admin)
  screens/
    auth/            -> Login
    wizard/           -> Setup Wizard 3-step
    dashboard/        -> Dashboard utama
    sender/           -> CRUD Sender Email & Telegram
    target/           -> CRUD + Import CSV Target
    report/           -> Kirim Laporan & Log Pengiriman
    settings/         -> Pengaturan (post-wizard)
    admin/            -> Kelola User (khusus admin)
  widgets/           -> komponen reusable (status indicator, stat card, dll)
```

## 5. Catatan Implementasi Penting

1. **Tanpa Emoji** — semua ikon menggunakan `Icons.xxx` (Material Icons), sesuai larangan di spesifikasi.
2. **Limit 200 Sender** — dicek di frontend (`SenderEmailListController.isQuotaFull` /
   `SenderTelegramListController.isQuotaFull`) untuk UX (sembunyikan tombol tambah),
   TAPI validasi sesungguhnya tetap di backend (middleware `CheckSenderLimit`).
3. **Subject Prefix** — field Subject di halaman Kirim Laporan HANYA berisi judul inti
   (tanpa prefix). Prefix ditampilkan sebagai info terpisah ("Prefix otomatis: ...")
   dan digabungkan oleh BACKEND saat diproses — ini untuk menghindari prefix terduplikasi.
4. **Rich Text Editor** — memakai `flutter_quill` untuk body laporan. Konversi ke HTML
   pada `send_report_screen.dart` (`_bodyToHtml()`) saat ini disederhanakan (paragraf per
   baris teks polos). Jika butuh format kaya (bold/italic/list) yang utuh dikirim sebagai
   HTML, ganti dengan package konversi delta→HTML yang lebih lengkap.
5. **Font** — Inter & Montserrat diambil otomatis lewat `google_fonts` (tidak perlu
   menyertakan file .ttf manual).
6. **Dark Mode** — diatur lewat `ThemeModeController` (Riverpod), disinkron dengan
   `theme_mode` di backend user_settings.

## 6. Testing Cepat

1. Jalankan backend Laravel (`php artisan serve` + `php artisan queue:work`).
2. Jalankan `flutter run`, login dengan akun admin seed (`admin` / `admin123`).
3. Karena `is_first_login = true`, akan langsung diarahkan ke Setup Wizard.
4. Selesaikan wizard → masuk Dashboard.
5. Tambahkan Sender Email/Telegram, Target, lalu coba Kirim Laporan.
