import 'package:flutter/material.dart';
import '../services/user_prefs.dart';
import '../services/app_service.dart';
import '../theme/app_theme.dart';
import 'main_nav.dart';
import 'login_screen.dart';
import 'maintenance_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;
  String _statusText = 'Memuat...';

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _fadeAnim  = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _scaleAnim = Tween<double>(begin: 0.7, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut));
    _ctrl.forward();
    _init();
  }

  Future<void> _init() async {
    await Future.delayed(const Duration(milliseconds: 1500));
    if (!mounted) return;

    // 0. Ambil domain server aktif dari GitHub (biar gampang pindah server
    //    tanpa perlu update APK semua user)
    await AppService.loadDomain();
    if (!mounted) return;

    // 1. Cek maintenance
    setState(() => _statusText = 'Menghubungi server...');
    final status = await AppService.checkMaintenance();
    if (!mounted) return;

    if (status['maintenance'] == true) {
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => MaintenanceScreen(
          message: status['maintenance_msg'] ?? '🔧 Server sedang maintenance.',
        ),
      ));
      return;
    }

    // 2. Cek token tersimpan
    final savedToken = await UserPrefs.getToken();
    final savedId    = await UserPrefs.getUserId();
    final savedRole  = await UserPrefs.getRole();
    if (!mounted) return;

    if (savedToken != null && savedId != null && savedToken.isNotEmpty) {
      // Token sudah ada — langsung masuk
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => MainNav(userId: savedId, role: savedRole ?? 'user')));
      return;
    }

    // 3. Belum punya akun / belum login — wajib daftar atau login dulu
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Stack(
        children: [
          // Signature element: medan energi ambient di pojok layar —
          // bukan dekorasi acak, jadi identitas visual "domain" yang
          // konsisten dipakai juga di header screen lain.
          Positioned(
            top: -140, right: -100,
            child: Container(
              width: 320, height: 320,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [AppTheme.accent.withValues(alpha: 0.22), Colors.transparent],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -160, left: -120,
            child: Container(
              width: 360, height: 360,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [AppTheme.indigo.withValues(alpha: 0.16), Colors.transparent],
                ),
              ),
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: ScaleTransition(
                scale: _scaleAnim,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 108, height: 108,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(
                          color: AppTheme.accent.withValues(alpha: 0.5),
                          blurRadius: 36, spreadRadius: 6,
                        )],
                      ),
                      child: ClipOval(
                        child: Image.asset('assets/icons/icon_192.png',
                            width: 108, height: 108, fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: AppTheme.cursedGradient,
                              ),
                              child: const Icon(Icons.bolt_rounded, size: 52, color: Colors.white),
                            )),
                      ),
                    ),
                    const SizedBox(height: 28),
                    ShaderMask(
                      shaderCallback: (b) => AppTheme.glowGradient.createShader(b),
                      child: Text('MIWA PAY',
                        style: AppTheme.display(size: 26, weight: FontWeight.w800, color: Colors.white, letterSpacing: 2),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text('powered by Miwa Pay', style: AppTheme.eyebrow(color: AppTheme.textMuted)),
                    const SizedBox(height: 44),
                    const SizedBox(width: 28, height: 28,
                      child: CircularProgressIndicator(strokeWidth: 2.4,
                          valueColor: AlwaysStoppedAnimation<Color>(AppTheme.accentLight)),
                    ),
                    const SizedBox(height: 16),
                    Text(_statusText, style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
