import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import '../theme/app_theme.dart';

class IntroVideoScreen extends StatefulWidget {
  final Widget destination;
  const IntroVideoScreen({super.key, required this.destination});

  @override
  State<IntroVideoScreen> createState() => _IntroVideoScreenState();
}

class _IntroVideoScreenState extends State<IntroVideoScreen> {
  late VideoPlayerController _ctrl;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    // Fullscreen tanpa status bar
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _initVideo();
  }

  Future<void> _initVideo() async {
    _ctrl = VideoPlayerController.asset('assets/video/intro.mp4');
    try {
      await _ctrl.initialize();
      if (!mounted) return;
      setState(() => _initialized = true);
      _ctrl.setLooping(false);
      _ctrl.setVolume(1.0);
      _ctrl.play();
      // Setelah video selesai → masuk ke home
      _ctrl.addListener(() {
        if (_ctrl.value.position >= _ctrl.value.duration &&
            _ctrl.value.duration > Duration.zero) {
          _goNext();
        }
      });
    } catch (e) {
      // Kalau video error, langsung skip ke home
      _goNext();
    }
  }

  void _goNext() {
    if (!mounted) return;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => widget.destination,
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 600),
      ),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Video fullscreen
          if (_initialized)
            Center(
              child: AspectRatio(
                aspectRatio: _ctrl.value.aspectRatio,
                child: VideoPlayer(_ctrl),
              ),
            )
          else
            // Loading saat video belum siap
            const Center(
              child: CircularProgressIndicator(color: AppTheme.accentLight),
            ),

          // Tombol skip pojok kanan atas
          Positioned(
            top: 48,
            right: 20,
            child: GestureDetector(
              onTap: _goNext,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white24),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Lewati', style: TextStyle(color: Colors.white70, fontSize: 13)),
                    SizedBox(width: 4),
                    Icon(Icons.skip_next_rounded, color: Colors.white70, size: 16),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
