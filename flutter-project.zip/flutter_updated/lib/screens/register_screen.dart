import 'package:flutter/material.dart';
import '../services/user_prefs.dart';
import '../services/app_service.dart';
import '../theme/app_theme.dart';
import 'main_nav.dart';
import 'intro_video_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _userCtrl  = TextEditingController();
  final _passCtrl  = TextEditingController();
  final _gmailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  bool _loading = false;
  bool _obscure = true;
  String? _err;

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _gmailCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    final username = _userCtrl.text.trim();
    final password = _passCtrl.text.trim();
    final gmail = _gmailCtrl.text.trim();
    final phone = _phoneCtrl.text.trim();

    if (username.isEmpty || password.isEmpty || gmail.isEmpty || phone.isEmpty) {
      setState(() => _err = 'Semua field wajib diisi');
      return;
    }

    setState(() { _loading = true; _err = null; });

    final result = await AppService.register(
      username: username, password: password, gmail: gmail, phone: phone,
    );

    if (!mounted) return;

    if (result['success'] == true) {
      // Langsung aktif, langsung masuk ke menu biasa (bukan menu admin)
      await UserPrefs.saveUserId(result['userId']);
      await UserPrefs.saveToken(result['token']);
      await UserPrefs.saveRole(result['role'] ?? 'user');
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => IntroVideoScreen(
          destination: MainNav(userId: result['userId'], role: result['role'] ?? 'user'),
        ),
      ));
    } else {
      setState(() { _err = result['message'] ?? 'Pendaftaran gagal'; _loading = false; });
    }
  }

  Widget _field({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(
            color: AppTheme.textSecondary, fontSize: 11, letterSpacing: 2)),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppTheme.card, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppTheme.border),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscure,
            keyboardType: keyboardType,
            style: const TextStyle(color: AppTheme.textPrimary),
            decoration: InputDecoration(
              prefixIcon: Icon(icon, color: AppTheme.textSecondary),
              suffixIcon: suffix,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            ),
          ),
        ),
        const SizedBox(height: 14),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_rounded, color: AppTheme.textPrimary),
              onPressed: () => Navigator.pop(context),
            ),
            const SizedBox(height: 8),
            ShaderMask(
              shaderCallback: (b) => const LinearGradient(
                colors: [AppTheme.accentLight, AppTheme.cyan],
              ).createShader(b),
              child: const Text('DAFTAR\nAKUN',
                style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold,
                    letterSpacing: 2, height: 1.1, color: Colors.white),
              ),
            ),
            const SizedBox(height: 8),
            const Text('Lengkapi data berikut untuk mulai pakai MiwaChan OTP',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
            const SizedBox(height: 28),

            _field(label: 'USERNAME', controller: _userCtrl, icon: Icons.person_rounded),
            _field(
              label: 'PASSWORD', controller: _passCtrl, icon: Icons.lock_rounded,
              obscure: _obscure,
              suffix: IconButton(
                icon: Icon(_obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                    color: AppTheme.textSecondary, size: 20),
                onPressed: () => setState(() => _obscure = !_obscure),
              ),
            ),
            _field(
              label: 'GMAIL', controller: _gmailCtrl, icon: Icons.email_rounded,
              keyboardType: TextInputType.emailAddress,
            ),
            _field(
              label: 'NOMOR TELEPON', controller: _phoneCtrl, icon: Icons.phone_rounded,
              keyboardType: TextInputType.phone,
            ),

            if (_err != null) ...[
              const SizedBox(height: 6),
              Text(_err!, style: const TextStyle(color: AppTheme.red, fontSize: 13)),
              const SizedBox(height: 6),
            ],

            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity, height: 52,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [AppTheme.accent, AppTheme.cyan]),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: AppTheme.accent.withValues(alpha: 0.4),
                      blurRadius: 20, offset: const Offset(0, 6))],
                ),
                child: TextButton(
                  onPressed: _loading ? null : _register,
                  child: _loading
                      ? const SizedBox(width: 22, height: 22,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('DAFTAR SEKARANG',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,
                              letterSpacing: 1.5, fontSize: 14)),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Center(
              child: TextButton(
                onPressed: _loading ? null : () => Navigator.pop(context),
                child: const Text('Sudah punya akun? Masuk',
                    style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
