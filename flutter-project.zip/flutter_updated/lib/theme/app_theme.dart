import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Token desain "Cursed Energy" — dibangun dari estetika domain expansion:
/// ruang gelap nyaris-hitam, energi ungu yang membakar di tepi, dan aksen
/// indigo sebagai medan sekunder. Merah hanya dipakai untuk status
/// bahaya/error, tidak untuk dekorasi.
class AppTheme {
  // ── Palette ──────────────────────────────────────────────────────────────
  static const Color bg = Color(0xFF0B0B10); // void hitam
  static const Color surface = Color(0xFF13131C); // permukaan kartu
  static const Color card = Color(0xFF191926); // kartu terangkat
  static const Color cardAlt = Color(0xFF1F1F2E); // kartu sekunder/hover

  static const Color accent = Color(0xFF6C2BD9); // ungu cursed energy
  static const Color accentLight = Color(0xFFA66BFF); // ungu terang (glow)
  static const Color indigo = Color(0xFF3F3CBB); // energi sekunder
  static const Color cyanGlow = Color(0xFF22D3EE); // dipakai sangat terbatas

  static const Color green = Color(0xFF22C55E); // sukses
  static const Color red = Color(0xFFE63950); // bahaya/error — dipakai khusus
  static const Color yellow = Color(0xFFF5A623); // pending/peringatan

  // Alias kompatibilitas — beberapa screen lama masih merujuk `cyan` sebagai
  // warna aksen sekunder. Tetap dipertahankan supaya tidak perlu ubah semua
  // pemanggil satu per satu.
  static const Color cyan = cyanGlow;

  static const Color textPrimary = Color(0xFFEDEDF4);
  static const Color textSecondary = Color(0xFF9A98AC);
  static const Color textMuted = Color(0xFF6B6980);
  static const Color border = Color(0xFF2A2A3D);
  static const Color borderGlow = Color(0x336C2BD9); // border ungu 20% opacity

  static const LinearGradient cursedGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [accent, indigo],
  );

  static const LinearGradient glowGradient = LinearGradient(
    colors: [accentLight, accent],
  );

  // ── Typography ───────────────────────────────────────────────────────────
  // Display: Sora — geometris, tegas, dipakai terbatas pada heading & angka besar.
  // Body: Plus Jakarta Sans — netral, sangat mudah dibaca di layar kecil.
  // Mono: dipertahankan KHUSUS untuk invoice ID, kode OTP, dan nominal —
  // konteks di mana spasi tetap antar-karakter membantu pembacaan data.
  static TextStyle display({
    double size = 28,
    FontWeight weight = FontWeight.w700,
    Color color = textPrimary,
    double? letterSpacing,
  }) =>
      GoogleFonts.sora(
        fontSize: size,
        fontWeight: weight,
        color: color,
        letterSpacing: letterSpacing ?? 0,
        height: 1.15,
      );

  static TextStyle body({
    double size = 14,
    FontWeight weight = FontWeight.w400,
    Color color = textPrimary,
    double? letterSpacing,
  }) =>
      GoogleFonts.plusJakartaSans(
        fontSize: size,
        fontWeight: weight,
        color: color,
        letterSpacing: letterSpacing,
      );

  static TextStyle mono({
    double size = 13,
    FontWeight weight = FontWeight.w500,
    Color color = textPrimary,
    double? letterSpacing,
  }) =>
      GoogleFonts.jetBrainsMono(
        fontSize: size,
        fontWeight: weight,
        color: color,
        letterSpacing: letterSpacing,
      );

  static TextStyle eyebrow({Color color = textSecondary}) => GoogleFonts.plusJakartaSans(
        fontSize: 11,
        fontWeight: FontWeight.w600,
        color: color,
        letterSpacing: 2,
      );

  // ── ThemeData ────────────────────────────────────────────────────────────
  static ThemeData get darkTheme {
    final base = ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(
        primary: accent,
        secondary: indigo,
        surface: surface,
        error: red,
      ),
      textTheme: GoogleFonts.plusJakartaSansTextTheme(ThemeData.dark().textTheme).apply(
        bodyColor: textPrimary,
        displayColor: textPrimary,
      ),
    );

    return base.copyWith(
      appBarTheme: AppBarTheme(
        backgroundColor: bg,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.sora(
          color: textPrimary,
          fontSize: 17,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
        iconTheme: const IconThemeData(color: textPrimary),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: accentLight,
        unselectedItemColor: textMuted,
        type: BottomNavigationBarType.fixed,
        showSelectedLabels: true,
        showUnselectedLabels: true,
      ),
      splashColor: accent.withValues(alpha: 0.08),
      highlightColor: Colors.transparent,
      dividerColor: border,
    );
  }
}
