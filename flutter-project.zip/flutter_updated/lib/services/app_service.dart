import 'dart:convert';
import 'package:http/http.dart' as http;
import 'user_prefs.dart';

class AppService {
  static String baseUrl = '';

  static const String _domainConfigUrl =
      'https://raw.githubusercontent.com/indzzinndzzz-afk/TAMPILAN-GOJO-CRASHER/refs/heads/main/domain.json';

  static Future<void> loadDomain() async {
    final cached = await UserPrefs.getCachedBaseUrl();
    if (cached != null && cached.isNotEmpty) baseUrl = cached;
    try {
      final res = await http
          .get(Uri.parse('$_domainConfigUrl?t=${DateTime.now().millisecondsSinceEpoch}'))
          .timeout(const Duration(seconds: 6));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final remoteUrl = (data['baseUrl'] as String?)?.trim();
        if (remoteUrl != null && remoteUrl.isNotEmpty) {
          baseUrl = remoteUrl;
          await UserPrefs.saveCachedBaseUrl(remoteUrl);
        }
      }
    } catch (_) {}
  }

  static Future<Map<String, dynamic>> checkMaintenance() async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/api/app/status'))
          .timeout(const Duration(seconds: 8));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'maintenance': false};
    }
  }

  static Future<Map<String, dynamic>> register({
    required String username,
    required String password,
    required String gmail,
    required String phone,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/api/auth/register'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'username': username, 'password': password, 'gmail': gmail, 'phone': phone}),
          )
          .timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> login({
    required String username,
    required String password,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/api/auth/login'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'username': username, 'password': password}),
          )
          .timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  /// Lupa password — kirim email, backend balas dengan password / reset link
  static Future<Map<String, dynamic>> forgotPassword({required String email}) async {
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/api/auth/forgot-password'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'email': email}),
          )
          .timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> fetchRegisteredUsers(String token) async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/api/auth/users'),
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  /// Polling status reset password
  static Future<Map<String, dynamic>> checkResetStatus(String token) async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/api/auth/reset-status?token=$token'))
          .timeout(const Duration(seconds: 8));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'status': 'pending', 'message': 'Gagal cek status'};
    }
  }

  /// Set password baru setelah admin approve
  static Future<Map<String, dynamic>> resetPassword({
    required String username,
    required String tempPassword,
    required String newPassword,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/api/auth/reset-password'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'username': username, 'tempPassword': tempPassword, 'newPassword': newPassword}),
          )
          .timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Gagal reset password'};
    }
  }
  // ── ADMIN: Deposit pending ────────────────────────────────────────────────
  static Future<Map<String, dynamic>> adminGetPendingDeposits(String token) async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/api/deposit/admin/pending'),
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> adminApproveDeposit(String token, String invoiceId) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/deposit/admin/approve'),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
        body: jsonEncode({'invoice_id': invoiceId}),
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> adminRejectDeposit(String token, String invoiceId) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/deposit/admin/reject'),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
        body: jsonEncode({'invoice_id': invoiceId}),
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  // ── ADMIN: Withdraw pending ───────────────────────────────────────────────
  static Future<Map<String, dynamic>> adminGetPendingWithdrawals(String token) async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/api/fr3/admin/pending-withdrawals'),
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> adminApproveWithdrawal(String token, String trxId) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/fr3/admin/approve-withdrawal'),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
        body: jsonEncode({'trx_id': trxId}),
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> adminRejectWithdrawal(String token, String trxId) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/api/fr3/admin/reject-withdrawal'),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
        body: jsonEncode({'trx_id': trxId}),
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  // ── RATING ───────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> getRatingMy(String token) async {
    try {
      final res = await http.get(
        Uri.parse('\$baseUrl/api/rating/my'),
        headers: {'Authorization': 'Bearer \$token'},
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> getRatingAll() async {
    try {
      final res = await http.get(
        Uri.parse('\$baseUrl/api/rating/all'),
        headers: {'Authorization': 'Bearer \${(await UserPrefs.getToken()) ?? ""}'},
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> submitRating({
    required String token,
    required int star,
    required String comment,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('\$baseUrl/api/rating/submit'),
        headers: {'Authorization': 'Bearer \$token', 'Content-Type': 'application/json'},
        body: jsonEncode({'star': star, 'comment': comment}),
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> adminGetAllRatings(String token) async {
    try {
      final res = await http.get(
        Uri.parse('\$baseUrl/api/rating/admin/all'),
        headers: {'Authorization': 'Bearer \$token'},
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  static Future<Map<String, dynamic>> adminDeleteRating(String token, String userId) async {
    try {
      final res = await http.delete(
        Uri.parse('\$baseUrl/api/rating/admin/delete'),
        headers: {'Authorization': 'Bearer \$token', 'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': userId}),
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Tidak bisa connect ke server'};
    }
  }

  // ── FCM TOKEN ─────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> updateFcmToken({
    required String authToken,
    required String fcmToken,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('\$baseUrl/api/auth/fcm-token'),
        headers: {'Authorization': 'Bearer \$authToken', 'Content-Type': 'application/json'},
        body: jsonEncode({'fcm_token': fcmToken}),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': 'Gagal update FCM token'};
    }
  }

}
