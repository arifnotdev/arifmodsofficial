import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';

class UserPrefs {
  static const _keyUserId = 'user_id';
  static const _keyToken  = 'auth_token';
  static const _keyRole   = 'user_role';

  static Future<String?> getRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyRole);
  }

  static Future<void> saveRole(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyRole, role);
  }

  static Future<bool> isAdmin() async {
    final role = await getRole();
    return role == 'admin';
  }

  static Future<String?> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyUserId);
  }

  static Future<void> saveUserId(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyUserId, id);
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyToken);
  }

  static Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyToken, token);
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  static const _keyBaseUrl = 'cached_base_url';

  static Future<String?> getCachedBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyBaseUrl);
  }

  static Future<void> saveCachedBaseUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyBaseUrl, url);
  }
  static Future<String> getOrCreateDeviceId() async {
    final prefs    = await SharedPreferences.getInstance();
    final existing = prefs.getString(_keyUserId);
    if (existing != null && existing.isNotEmpty) return existing;

    // Generate UUID-like unique ID
    final rand = Random.secure();
    String hex(int n) => rand.nextInt(n).toRadixString(16).padLeft(2, '0');
    final id = 'mw-${hex(256)}${hex(256)}-${hex(256)}${hex(256)}-${hex(256)}${hex(256)}-${hex(256)}${hex(256)}${hex(256)}${hex(256)}';
    await prefs.setString(_keyUserId, id);
    return id;
  }

  // ── FCM Token ──────────────────────────────────────────────────────────────
  static const String _keyFcmToken = 'fcm_token';

  static Future<void> saveFcmToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyFcmToken, token);
  }

  static Future<String?> getFcmToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyFcmToken);
  }
}
