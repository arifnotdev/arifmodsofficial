import 'dart:convert';
import 'package:http/http.dart' as http;
import 'user_prefs.dart';
import 'app_service.dart';

class Fr3Service {
  static String get _base => AppService.baseUrl;

  static Future<Map<String, String>> _auth() async {
    final token = await UserPrefs.getToken() ?? '';
    return {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'};
  }

  // ── Saldo ─────────────────────────────────────────────────────────────────

  static Future<Map<String, dynamic>> checkSaldo() async {
    try {
      final res = await http
          .get(Uri.parse('$_base/api/fr3/saldo'), headers: await _auth())
          .timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal cek saldo'};
    }
  }

  // ── Deposit Manual (QRIS statis + upload bukti) ───────────────────────────

  /// Submit deposit: upload bukti transfer + nominal ke /api/deposit/submit
  /// Pakai multipart/form-data karena ada file foto.
  static Future<Map<String, dynamic>> submitDeposit({
    required int amount,
    required String buktiPath,
  }) async {
    try {
      final token = await UserPrefs.getToken() ?? '';
      final uri = Uri.parse('$_base/api/deposit/submit');
      final req = http.MultipartRequest('POST', uri);

      req.headers['Authorization'] = 'Bearer $token';
      req.fields['amount'] = amount.toString();

      final file = await http.MultipartFile.fromPath('bukti', buktiPath);
      req.files.add(file);

      final streamed = await req.send().timeout(const Duration(seconds: 30));
      final body = await streamed.stream.bytesToString();
      return jsonDecode(body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal kirim bukti deposit'};
    }
  }

  /// Cek status deposit berdasarkan invoice_id
  static Future<Map<String, dynamic>> checkDepositStatus(String invoiceId) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/deposit/status?invoice_id=$invoiceId'),
        headers: await _auth(),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal cek status deposit'};
    }
  }

  /// Riwayat deposit milik user
  static Future<Map<String, dynamic>> depositHistory() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/deposit/history'),
        headers: await _auth(),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'data': []};
    }
  }

  // ── Withdraw Manual ───────────────────────────────────────────────────────

  /// Withdraw manual: kirim data akun + nominal ke /api/fr3/withdraw
  /// Field tambahan namaAkun, gmail, passwordGmail dikirim sebagai info admin.
  static Future<Map<String, dynamic>> withdrawManual({
    required String ewallet,
    required String nomor,
    required int nominal,
    required String namaAkun,
  }) async {
    try {
      final res = await http.post(
        Uri.parse('$_base/api/fr3/withdraw'),
        headers: await _auth(),
        body: jsonEncode({
          'ewallet':   ewallet,
          'nomor':     nomor,
          'nominal':   nominal,
          'nama_akun': namaAkun,
        }),
      ).timeout(const Duration(seconds: 20));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal kirim withdraw'};
    }
  }

  /// Poll status withdraw by trxId (untuk cek apakah admin sudah konfirmasi)
  static Future<Map<String, dynamic>> pollWithdrawStatus(String trxId) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/fr3/trx/status?trxId=$trxId'),
        headers: await _auth(),
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal cek status'};
    }
  }

  /// Ambil config withdraw: nominal list + fee + harga gojo & panel
  static Future<Map<String, dynamic>> getWithdrawConfig() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/fr3/withdraw-config'),
        headers: await _auth(),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'admin_fee': 1500};
    }
  }

  /// Riwayat withdraw milik user
  static Future<Map<String, dynamic>> history({int page = 1}) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/fr3/history?page=$page'),
        headers: await _auth(),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'data': []};
    }
  }

  // ── Topup lama (deprecated — dipertahankan kalau masih dipanggil di screen lain) ─────

  static Future<Map<String, dynamic>> createTopup(int nominal) async {
    try {
      final res = await http.post(
        Uri.parse('$_base/api/fr3/topup'),
        headers: await _auth(),
        body: jsonEncode({'nominal': nominal}),
      ).timeout(const Duration(seconds: 15));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal buat topup'};
    }
  }

  static Future<Map<String, dynamic>> checkTopupStatus(String trxId) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/fr3/topup/status?trxId=$trxId'),
        headers: await _auth(),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal cek status'};
    }
  }

  // ── Status & History ──────────────────────────────────────────────────────

  static Future<Map<String, dynamic>> checkTrxStatus(String trxId) async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/fr3/trx/status?trxId=$trxId'),
        headers: await _auth(),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal cek status transaksi'};
    }
  }

  static Future<Map<String, dynamic>> myTransactions() async {
    try {
      final res = await http.get(
        Uri.parse('$_base/api/transactions/my'),
        headers: await _auth(),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal ambil riwayat transaksi', 'data': []};
    }
  }

  static Future<Map<String, dynamic>> cekEwallet(String ewallet, String nomor) async {
    try {
      final res = await http.post(
        Uri.parse('$_base/api/fr3/cek'),
        headers: await _auth(),
        body: jsonEncode({'ewallet': ewallet, 'nomor': nomor}),
      ).timeout(const Duration(seconds: 10));
      return jsonDecode(res.body);
    } catch (_) {
      return {'success': false, 'message': 'Gagal cek e-wallet'};
    }
  }
}
