const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'miwachan_secret';

/**
 * Middleware verifikasi JWT token
 * Token dikirim via header: Authorization: Bearer <token>
 */
function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Token tidak ada. Login dulu ya!',
    });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Token invalid atau expired. Login ulang!',
    });
  }
}

/**
 * Generate JWT token
 */
function generateToken(payload, expiresIn = '30d') {
  return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

/**
 * Middleware tambahan: hanya boleh lewat kalau role di token = admin
 * Pasang SETELAH authMiddleware
 */
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Khusus admin. Akses ditolak.',
    });
  }
  next();
}

module.exports = { authMiddleware, generateToken, requireAdmin };
