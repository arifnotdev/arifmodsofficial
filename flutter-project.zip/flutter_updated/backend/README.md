# OTP MIWACHAN BACKEND v3

## Perubahan dari v2

### ✅ Fitur Baru
1. **Tanpa Login** — User tidak perlu input apapun. App auto-register by deviceId
2. **QRIS dari Assets Flutter** — Letakkan `qris_static.png` di `flutter/assets/qris/` (tidak perlu host di server)
3. **Domain bisa diubah via Telegram** — `/setdomain https://domain-baru.com`
4. **Admin Panel Lengkap** di Telegram:
   - `/users` — Daftar semua pengguna
   - `/user [id]` — Detail + statistik per user
   - `/orders` — Semua order hari ini
   - `/pendingorders` — Order masih pending
   - `/successorders` — Order sudah sukses
   - `/alldeposits` — Semua deposit (bukan hanya pending)
   - `/stats` — Statistik lengkap hari ini

---

## Setup Awal

### 1. Clone & Install
```bash
git clone https://github.com/kamu/otp-miwachan.git
cd backend
npm install
```

### 2. Konfigurasi .env
```bash
cp .env.example .env
nano .env
```
Isi minimal:
- `JWT_SECRET` — ganti dengan string acak panjang
- `TELEGRAM_BOT_TOKEN` — token bot dari @BotFather
- `TELEGRAM_ADMIN_ID` — chat ID Telegram kamu
- `SERVER_URL` — URL domain deploy awal
- `RUANGOTP_USER_ID` — user ID RuangOTP

### 3. Deploy & Set Webhook
```bash
node index.js
```
Lalu buka: `https://your-domain.com/api/telegram/set-webhook`

### 4. Ganti Domain via Telegram
Kirim ke bot: `/setdomain https://domain-baru.com`  
Bot otomatis update webhook Telegram juga.

---

## Setup Flutter

### QRIS dari Assets
1. Buat folder `flutter/assets/qris/`
2. Copy file QRIS kamu → `flutter/assets/qris/qris_static.png`
3. Update `BASE_URL` di `flutter/lib/services/app_service.dart`
4. Build APK

### Tidak Ada Halaman Login
- App langsung masuk setelah splash screen
- User diidentifikasi by device ID (UUID unik per device)
- Admin bisa lihat semua user via `/users` di Telegram

---

## Telegram Admin Commands

| Command | Fungsi |
|---------|--------|
| `/menu` | Tampilkan semua command |
| `/domain` | Lihat domain aktif |
| `/setdomain [URL]` | Ganti domain + update webhook |
| `/users` | Semua pengguna terdaftar |
| `/user [deviceId]` | Detail pengguna |
| `/deposits` | Deposit pending |
| `/alldeposits` | Semua deposit |
| `/deposit [invoice]` | Detail + konfirmasi/tolak deposit |
| `/orders` | Order hari ini |
| `/pendingorders` | Order pending |
| `/successorders` | Order sukses |
| `/markup` | Lihat markup |
| `/setmarkup flat/percent/off [val]` | Set markup |
| `/maintenance` | Status maintenance |
| `/maintenance on/off` | Toggle maintenance |
| `/stats` | Statistik hari ini |
