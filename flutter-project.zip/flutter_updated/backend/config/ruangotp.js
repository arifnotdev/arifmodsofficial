require('dotenv').config();
const axios = require('axios');

const RUANGOTP_BASE = process.env.RUANGOTP_BASE || 'https://api.ruangotp.site/api/v2';
const RUANGOTP_USER_ID = process.env.RUANGOTP_USER_ID || '';

const ruangOTP = axios.create({
  baseURL: RUANGOTP_BASE,
  timeout: 15000,
  headers: {
    'x-user-id': RUANGOTP_USER_ID,
    'Content-Type': 'application/json',
  },
});

// Interceptor log
ruangOTP.interceptors.request.use((config) => {
  console.log(`[RuangOTP] ${config.method?.toUpperCase()} ${config.url}`, config.params || '');
  return config;
});

ruangOTP.interceptors.response.use(
  (res) => res,
  (err) => {
    console.error('[RuangOTP Error]', err.response?.data || err.message);
    return Promise.reject(err);
  }
);

module.exports = { ruangOTP };
