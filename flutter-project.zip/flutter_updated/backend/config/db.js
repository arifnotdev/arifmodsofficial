const { db } = require('./firebase');

// ─── Koleksi Firestore ────────────────────────────────────────────────────────
const usersCol     = db.collection('users');
const depositsCol  = db.collection('deposits');
const ordersCol    = db.collection('orders');
const withdrawsCol = db.collection('withdrawals');
const resetsCol    = db.collection('password_resets');
const configDoc    = db.collection('config').doc('app'); // singleton doc

const DEFAULT_CONFIG = {
  markup: 0,
  markup_type: 'flat',
  maintenance: false,
  maintenance_msg: '🔧 Server sedang maintenance. Tunggu bentar ya!',
  domain: process.env.SERVER_URL || '',
};

// ─── Helper: convert snapshot koleksi -> object { docId: data } ─────────────
// Ini supaya bentuk return-nya SAMA seperti waktu masih JSON file based,
// jadi semua route (Object.values, users[key], dst) tidak perlu diubah.
function snapshotToObject(snapshot) {
  const result = {};
  snapshot.forEach((doc) => { result[doc.id] = doc.data(); });
  return result;
}

// ─── USERS ────────────────────────────────────────────────────────────────────
async function readUsers() {
  const snap = await usersCol.get();
  return snapshotToObject(snap);
}

// writeUsers menerima OBJECT LENGKAP { username: {...}, ... } seperti dulu.
// Supaya kompatibel sama pola "read -> ubah di JS -> write balik semuanya"
// yang dipakai di routes, kita commit per-document lewat batch.
async function writeUsers(usersObj) {
  const batch = db.batch();
  Object.entries(usersObj).forEach(([key, value]) => {
    batch.set(usersCol.doc(key), value, { merge: false });
  });
  await batch.commit();
}

function findUserKeyByUsername(users, username) {
  const target = username.trim().toLowerCase();
  return Object.keys(users).find((k) => k.toLowerCase() === target) || null;
}

// ─── DEPOSITS ─────────────────────────────────────────────────────────────────
async function readDeposits() {
  const snap = await depositsCol.get();
  return snapshotToObject(snap);
}

async function writeDeposits(depositsObj) {
  const batch = db.batch();
  Object.entries(depositsObj).forEach(([key, value]) => {
    batch.set(depositsCol.doc(key), value, { merge: false });
  });
  await batch.commit();
}

// ─── ORDERS ───────────────────────────────────────────────────────────────────
async function readOrders() {
  const snap = await ordersCol.get();
  return snapshotToObject(snap);
}

async function writeOrders(ordersObj) {
  const batch = db.batch();
  Object.entries(ordersObj).forEach(([key, value]) => {
    batch.set(ordersCol.doc(key), value, { merge: false });
  });
  await batch.commit();
}

// ─── WITHDRAWALS ──────────────────────────────────────────────────────────────
async function readWithdrawals() {
  const snap = await withdrawsCol.get();
  return snapshotToObject(snap);
}

async function writeWithdrawals(withdrawalsObj) {
  const batch = db.batch();
  Object.entries(withdrawalsObj).forEach(([key, value]) => {
    batch.set(withdrawsCol.doc(key), value, { merge: false });
  });
  await batch.commit();
}

// ─── PASSWORD RESETS (pending reset request — disimpan ke Firestore biar
//     tahan restart server, bukan in-memory lagi) ──────────────────────────
async function createPasswordReset(token, data) {
  await resetsCol.doc(token).set({ ...data, created_at_ts: Date.now() });
}

async function getPasswordReset(token) {
  const snap = await resetsCol.doc(token).get();
  return snap.exists ? snap.data() : null;
}

async function updatePasswordReset(token, partial) {
  await resetsCol.doc(token).set(partial, { merge: true });
}

async function deletePasswordReset(token) {
  await resetsCol.doc(token).delete();
}

// ─── CONFIG (singleton document) ─────────────────────────────────────────────
async function readConfig() {
  const snap = await configDoc.get();
  if (!snap.exists) {
    await configDoc.set(DEFAULT_CONFIG);
    return { ...DEFAULT_CONFIG };
  }
  return { ...DEFAULT_CONFIG, ...snap.data() };
}

async function writeConfig(configObj) {
  await configDoc.set(configObj, { merge: true });
}

module.exports = {
  readDeposits, writeDeposits,
  readWithdrawals, writeWithdrawals,
  readConfig, writeConfig,
  readUsers, writeUsers,
  readOrders, writeOrders,
  findUserKeyByUsername,
  createPasswordReset, getPasswordReset, updatePasswordReset, deletePasswordReset,
};
