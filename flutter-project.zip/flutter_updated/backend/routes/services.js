const express = require('express');
const router = express.Router();
const { ruangOTP } = require('../config/ruangotp');
const { authMiddleware } = require('../middleware/auth');

// Semua route butuh auth
router.use(authMiddleware);

/**
 * GET /api/services
 * Daftar layanan (whatsapp, telegram, dll)
 */
router.get('/', async (req, res) => {
  try {
    const { data } = await ruangOTP.get('/services', {
      headers: { 'x-user-id': req.user.userId },
    });
    res.json(data);
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.response?.data?.message || 'Gagal ambil services',
    });
  }
});

/**
 * GET /api/services/countries?service_id=whatsapp
 * Daftar negara + pricelist per service
 */
router.get('/countries', async (req, res) => {
  const { service_id } = req.query;
  if (!service_id) {
    return res.status(400).json({ success: false, message: 'service_id wajib' });
  }
  try {
    const { data } = await ruangOTP.get('/country', {
      params: { service_id },
      headers: { 'x-user-id': req.user.userId },
    });
    res.json(data);
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.response?.data?.message || 'Gagal ambil countries',
    });
  }
});

/**
 * GET /api/services/operators?country_id=6
 */
router.get('/operators', async (req, res) => {
  const { country_id } = req.query;
  if (!country_id) {
    return res.status(400).json({ success: false, message: 'country_id wajib' });
  }
  try {
    const { data } = await ruangOTP.get('/operators', {
      params: { country_id },
      headers: { 'x-user-id': req.user.userId },
    });
    res.json(data);
  } catch (err) {
    res.status(500).json({
      success: false,
      message: err.response?.data?.message || 'Gagal ambil operators',
    });
  }
});

module.exports = router;
