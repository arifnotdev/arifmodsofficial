const express = require('express');
const router  = express.Router();
const { authMiddleware } = require('../middleware/auth');
const { readDeposits, readOrders, readWithdrawals } = require('../config/db');

router.use(authMiddleware);

// GET /api/transactions/my
// Gabungan riwayat: deposit (topup), withdraw (tarik saldo), order (beli OTP/produk)
// — semuanya milik user yang sedang login, diurutkan dari yang terbaru.
router.get('/my', async (req, res) => {
  const userId = req.user.userId;
  try {
    const [deposits, orders, withdrawals] = await Promise.all([
      readDeposits(), readOrders(), readWithdrawals(),
    ]);

    const list = [];

    Object.values(deposits)
      .filter((d) => d.user_id === userId)
      .forEach((d) => list.push({
        id: d.invoice_id,
        type: 'topup',
        title: 'Topup Saldo',
        amount: d.final_amount ?? d.amount,
        status: d.status,
        created_at: d.created_at,
        detail: { markup: d.markup, amount: d.amount, bukti_url: d.bukti_url },
      }));

    Object.values(withdrawals)
      .filter((w) => w.user_id === userId)
      .forEach((w) => list.push({
        id: w.trx_id,
        type: 'withdraw',
        title: `Tarik Saldo — ${(w.ewallet || '').toUpperCase()}`,
        amount: w.nominal,
        status: w.status,
        created_at: w.created_at,
        detail: { ewallet: w.ewallet, nomor: w.nomor, message: w.message },
      }));

    Object.values(orders)
      .filter((o) => o.user_id === userId)
      .forEach((o) => list.push({
        id: o.invoice_id,
        type: 'order',
        title: o.service_name || 'Order Produk',
        amount: o.price,
        status: o.status,
        created_at: o.created_at,
        detail: { country_name: o.country_name, product_code: o.product_code },
      }));

    list.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    res.json({ success: true, data: list });
  } catch (err) {
    console.error('[MY TRANSACTIONS ERROR]', err);
    res.status(500).json({ success: false, message: 'Gagal ambil riwayat transaksi', data: [] });
  }
});

module.exports = router;
