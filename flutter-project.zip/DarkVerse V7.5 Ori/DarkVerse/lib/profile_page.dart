import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'change_password_page.dart';

// ─────────────────────────────────────────────────────────────
//  PALETTE
// ─────────────────────────────────────────────────────────────
const Color _void    = Color(0xFF000000);
const Color _plate   = Color(0xFF0A0000);
const Color _surface = Color(0xFF0D0000);
const Color _rim     = Color(0xFF1A0000);
const Color _rimHi   = Color(0xFF2A0000);
const Color _red     = Color(0xFFFF1744);
const Color _redDim  = Color(0xFFD50000);
const Color _redDark = Color(0xFF8B0000);
const Color _ash     = Color(0xFF8B6060);
const Color _slate   = Color(0xFF4A2020);
const Color _snow    = Color(0xFFF1F0F5);

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();
  bool _sessionRevealed = false;

  late AnimationController _glowCtrl;
  late AnimationController _scanCtrl;
  late AnimationController _enterCtrl;

  @override
  void initState() {
    super.initState();

    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);

    _scanCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 5))
      ..repeat();

    _enterCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..forward();

    _loadProfileImage();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _scanCtrl.dispose();
    _enterCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_${widget.username}');
    if (path != null && path.isNotEmpty) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? f = await _picker.pickImage(source: source, imageQuality: 70);
      if (f != null) {
        final img = File(f.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', img.path);
        setState(() => _profileImage = img);
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
    }
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: _plate,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => _ImageSourceSheet(
        onCamera: () { Navigator.pop(context); _pickImage(ImageSource.camera); },
        onGallery: () { Navigator.pop(context); _pickImage(ImageSource.gallery); },
      ),
    );
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return 'N/A';
    if (isPassword) return '••••••••';
    if (text.length <= 2) return '${text[0]}••';
    return '${text.substring(0, 2)}${'•' * (text.length - 2)}';
  }

  // ── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _void,
      body: Stack(children: [
        // bg scan
        RepaintBoundary(
          child: AnimatedBuilder(
            animation: _scanCtrl,
            builder: (_, __) => CustomPaint(
              size: MediaQuery.of(context).size,
              painter: _ProfileBgPainter(t: _scanCtrl.value),
            ),
          ),
        ),

        SafeArea(
          child: Column(children: [
            _buildAppBar(),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(children: [
                  const SizedBox(height: 10),
                  _buildHeroCard(),
                  const SizedBox(height: 20),
                  _buildDataSection(),
                  const SizedBox(height: 14),
                  _buildSessionKeyCard(),
                  const SizedBox(height: 24),
                  _buildChangePasswordButton(),
                  const SizedBox(height: 28),
                  _buildFooter(),
                  const SizedBox(height: 30),
                ]),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  // ── APP BAR ──────────────────────────────────────────────
  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Row(children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: _plate,
              border: Border.all(color: _rim, width: 1),
            ),
            child: const Icon(Icons.arrow_back_ios_new,
                color: _snow, size: 15),
          ),
        ),
        const Spacer(),
        const Text('OPERATOR FILE',
            style: TextStyle(
                color: _snow,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: 13,
                letterSpacing: 2.5)),
        const Spacer(),
        // balance spacer
        const SizedBox(width: 38),
      ]),
    );
  }

  // ── HERO CARD ────────────────────────────────────────────
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: AnimatedBuilder(
        animation: _glowCtrl,
        builder: (_, __) {
          final g = _glowCtrl.value;
          return Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: _plate,
              border: Border.all(
                  color: _redDark.withValues(alpha: 0.3 + g * 0.2), width: 1),
              boxShadow: [
                BoxShadow(
                    color: _red.withValues(alpha: 0.06 + g * 0.04),
                    blurRadius: 30,
                    spreadRadius: -4),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Stack(children: [
                // diagonal stripe bg
                Positioned.fill(
                  child: CustomPaint(painter: _HeroStripePainter()),
                ),

                // top-left clearance tag
                Positioned(top: 14, left: 14,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: _redDark.withValues(alpha: 0.25),
                      border: Border.all(
                          color: _redDark.withValues(alpha: 0.4), width: 0.8),
                    ),
                    child: const Text('CLASSIFIED',
                        style: TextStyle(
                            color: _redDim,
                            fontFamily: 'ShareTechMono',
                            fontSize: 8,
                            letterSpacing: 2)),
                  ),
                ),

                // top-right file number
                Positioned(top: 14, right: 14,
                  child: Text(
                    '#${widget.username.hashCode.abs() % 9999 + 1000}',
                    style: TextStyle(
                        color: _ash.withValues(alpha: 0.4),
                        fontFamily: 'ShareTechMono',
                        fontSize: 9,
                        letterSpacing: 1),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 42, 20, 22),
                  child: Column(children: [
                    // avatar
                    GestureDetector(
                      onTap: _showImageSourceDialog,
                      child: _buildAvatar(g),
                    ),
                    const SizedBox(height: 18),

                    // username
                    Text(widget.username,
                        style: const TextStyle(
                            color: _snow,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 22,
                            letterSpacing: 2)),
                    const SizedBox(height: 12),

                    // role + expiry row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _RolePill(role: widget.role, glow: g),
                        const SizedBox(width: 10),
                        _ExpiryPill(date: widget.expiredDate),
                      ],
                    ),
                  ]),
                ),

                // bottom edge line
                Positioned(bottom: 0, left: 0, right: 0,
                  child: Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [
                        Colors.transparent,
                        _red.withValues(alpha: 0.25),
                        Colors.transparent,
                      ]),
                    ),
                  ),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _buildAvatar(double glowVal) {
    return Stack(alignment: Alignment.center, children: [
      // glow ring
      AnimatedBuilder(
        animation: _glowCtrl,
        builder: (_, __) => Container(
          width: 106, height: 106,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                  color: _red.withValues(alpha: 0.08 + glowVal * 0.1),
                  blurRadius: 24 + glowVal * 12,
                  spreadRadius: 2),
            ],
          ),
        ),
      ),

      // avatar circle
      Container(
        width: 100, height: 100,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _surface,
          border: Border.all(
              color: _redDark.withValues(alpha: 0.4 + glowVal * 0.3),
              width: 1.5),
        ),
        child: ClipOval(
          child: _profileImage != null
              ? Image.file(_profileImage!, fit: BoxFit.cover)
              : Center(
                  child: Icon(FontAwesomeIcons.userAstronaut,
                      size: 36,
                      color: _snow.withValues(alpha: 0.2)),
                ),
        ),
      ),

      // corner brackets
      ..._cornerBrackets(size: 118, bracketSize: 16, color: _red.withValues(alpha: 0.5 + glowVal * 0.3)),

      // camera badge
      Positioned(bottom: 2, right: 2,
        child: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: _rim,
            shape: BoxShape.circle,
            border: Border.all(color: _void, width: 2.5),
            boxShadow: [BoxShadow(
                color: _red.withValues(alpha: 0.3), blurRadius: 8)],
          ),
          child: const Icon(Icons.camera_alt, size: 12, color: _red),
        ),
      ),
    ]);
  }

  List<Widget> _cornerBrackets({
    required double size,
    required double bracketSize,
    required Color color,
  }) {
    final half = size / 2;
    return [
      // top-left
      Positioned(
        left: half - bracketSize - 8,
        top: half - bracketSize - 8,
        child: _CornerBracket(size: bracketSize, top: true, left: true, color: color),
      ),
      // top-right
      Positioned(
        right: half - bracketSize - 8,
        top: half - bracketSize - 8,
        child: _CornerBracket(size: bracketSize, top: true, left: false, color: color),
      ),
      // bottom-left
      Positioned(
        left: half - bracketSize - 8,
        bottom: half - bracketSize - 8,
        child: _CornerBracket(size: bracketSize, top: false, left: true, color: color),
      ),
      // bottom-right
      Positioned(
        right: half - bracketSize - 8,
        bottom: half - bracketSize - 8,
        child: _CornerBracket(size: bracketSize, top: false, left: false, color: color),
      ),
    ];
  }

  // ── DATA SECTION ─────────────────────────────────────────
  Widget _buildDataSection() {
    final rows = [
      _DataRow(icon: Icons.person_outline_rounded,      label: 'USERNAME', value: _censorText(widget.username)),
      _DataRow(icon: Icons.lock_outline_rounded,         label: 'PASSWORD', value: _censorText(widget.password, isPassword: true)),
      _DataRow(icon: Icons.verified_user_outlined,       label: 'ROLE',     value: widget.role.toUpperCase()),
      _DataRow(icon: Icons.calendar_today_outlined,      label: 'EXPIRED',  value: widget.expiredDate),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: _plate,
          border: Border.all(color: _rim, width: 1),
        ),
        child: Column(children: [
          // header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(children: [
              Container(width: 2, height: 13,
                decoration: BoxDecoration(
                  color: _red, borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(
                      color: _red.withValues(alpha: 0.5), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              const Text('ACCOUNT DATA',
                  style: TextStyle(
                      color: _ash,
                      fontFamily: 'Orbitron',
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3)),
            ]),
          ),
          const SizedBox(height: 6),
          // rows
          ...rows.asMap().entries.map((entry) {
            final i = entry.key;
            final r = entry.value;
            return _buildDataRowWidget(r, isLast: i == rows.length - 1);
          }),
        ]),
      ),
    );
  }

  Widget _buildDataRowWidget(_DataRow row, {required bool isLast}) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        child: Row(children: [
          // icon
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(9),
              color: _surface,
              border: Border.all(color: _rim, width: 1),
            ),
            child: Icon(row.icon, color: _redDark, size: 15),
          ),
          const SizedBox(width: 12),

          // label
          SizedBox(
            width: 80,
            child: Text(row.label,
                style: const TextStyle(
                    color: _ash,
                    fontFamily: 'ShareTechMono',
                    fontSize: 10,
                    letterSpacing: 1)),
          ),

          // dotted leader
          Expanded(
            child: Row(children: [
              Expanded(
                child: LayoutBuilder(builder: (_, c) {
                  const dotW = 3.0, gap = 4.0;
                  final count = (c.maxWidth / (dotW + gap)).floor();
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(count, (_) => Container(
                      width: dotW, height: 1,
                      color: _slate.withValues(alpha: 0.5),
                    )),
                  );
                }),
              ),
            ]),
          ),

          // value
          const SizedBox(width: 10),
          Text(row.value,
              style: const TextStyle(
                  color: _snow,
                  fontFamily: 'ShareTechMono',
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5)),
        ]),
      ),
      if (!isLast)
        Container(height: 1, margin: const EdgeInsets.symmetric(horizontal: 16),
          color: _rim.withValues(alpha: 0.5)),
    ]);
  }

  // ── SESSION KEY CARD ─────────────────────────────────────
  Widget _buildSessionKeyCard() {
    final masked = '${widget.sessionKey.substring(0, 8)}••••••••••••••••';
    final revealed = widget.sessionKey;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: GestureDetector(
        onLongPress: () {
          HapticFeedback.mediumImpact();
          setState(() => _sessionRevealed = !_sessionRevealed);
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: _plate,
            border: Border.all(color: _rim, width: 1),
          ),
          child: Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: _redDark.withValues(alpha: 0.15),
                border: Border.all(
                    color: _redDark.withValues(alpha: 0.3), width: 1),
              ),
              child: const Icon(Icons.vpn_key_rounded, color: _red, size: 17),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('SESSION KEY',
                      style: TextStyle(
                          color: _ash,
                          fontFamily: 'ShareTechMono',
                          fontSize: 9.5,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 4),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: Text(
                      _sessionRevealed ? revealed : masked,
                      key: ValueKey(_sessionRevealed),
                      style: const TextStyle(
                          color: _snow,
                          fontFamily: 'ShareTechMono',
                          fontSize: 11.5,
                          letterSpacing: 0.3),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: _surface,
                border: Border.all(color: _rim),
              ),
              child: Text(
                _sessionRevealed ? 'HIDE' : 'HOLD',
                style: const TextStyle(
                    color: _ash,
                    fontFamily: 'ShareTechMono',
                    fontSize: 8,
                    letterSpacing: 1),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ── CHANGE PASSWORD BUTTON ───────────────────────────────
  Widget _buildChangePasswordButton() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: AnimatedBuilder(
        animation: _glowCtrl,
        builder: (_, __) {
          final g = _glowCtrl.value;
          return GestureDetector(
            onTap: () {
              HapticFeedback.heavyImpact();
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => ChangePasswordPage(
                    username: widget.username,
                    sessionKey: widget.sessionKey),
              ));
            },
            child: Container(
              height: 58,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                color: _surface,
                border: Border.all(
                    color: _redDark.withValues(alpha: 0.35 + g * 0.25),
                    width: 1.5),
                boxShadow: [
                  BoxShadow(
                      color: _red.withValues(alpha: 0.07 + g * 0.06),
                      blurRadius: 20 + g * 10,
                      spreadRadius: -4),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Stack(alignment: Alignment.center, children: [
                  // top sheen
                  Positioned(top: 0, left: 0, right: 0,
                    child: Container(
                      height: 28,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            _red.withValues(alpha: 0.05),
                            Colors.transparent,
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                    ),
                  ),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: _red.withValues(alpha: 0.1),
                        border: Border.all(
                            color: _red.withValues(alpha: 0.3), width: 1),
                      ),
                      child: const Icon(Icons.lock_reset_rounded,
                          color: _red, size: 18),
                    ),
                    const SizedBox(width: 14),
                    const Text('CHANGE PASSWORD',
                        style: TextStyle(
                            color: _snow,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 2)),
                  ]),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }

  // ── FOOTER ───────────────────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: Column(children: [
        Container(height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              Colors.transparent,
              _rimHi.withValues(alpha: 0.5),
              Colors.transparent,
            ]),
          ),
        ),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(width: 20, height: 1, color: _slate.withValues(alpha: 0.4)),
          const SizedBox(width: 8),
          Container(width: 4, height: 4,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: _slate)),
          const SizedBox(width: 8),
          const Text('DARKVERSE PROFILE',
              style: TextStyle(
                  color: _slate,
                  fontFamily: 'Orbitron',
                  fontSize: 8,
                  letterSpacing: 3)),
          const SizedBox(width: 8),
          Container(width: 4, height: 4,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: _slate)),
          const SizedBox(width: 8),
          Container(width: 20, height: 1, color: _slate.withValues(alpha: 0.4)),
        ]),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  CORNER BRACKET WIDGET
// ─────────────────────────────────────────────────────────────
class _CornerBracket extends StatelessWidget {
  final double size;
  final bool top;
  final bool left;
  final Color color;
  const _CornerBracket({
    required this.size,
    required this.top,
    required this.left,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _BracketPainter(top: top, left: left, color: color),
      ),
    );
  }
}

class _BracketPainter extends CustomPainter {
  final bool top, left;
  final Color color;
  const _BracketPainter({required this.top, required this.left, required this.color});

  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 1.8
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.square;

    final x = left ? 0.0 : s.width;
    final y = top  ? 0.0 : s.height;
    final dx = left ? s.width  : -s.width;
    final dy = top  ? s.height : -s.height;

    // horizontal arm
    canvas.drawLine(Offset(x, y), Offset(x + dx, y), p);
    // vertical arm
    canvas.drawLine(Offset(x, y), Offset(x, y + dy), p);
  }

  @override
  bool shouldRepaint(_BracketPainter o) =>
      o.top != top || o.left != left || o.color != color;
}

// ─────────────────────────────────────────────────────────────
//  ROLE & EXPIRY PILLS
// ─────────────────────────────────────────────────────────────
class _RolePill extends StatelessWidget {
  final String role;
  final double glow;
  const _RolePill({required this.role, required this.glow});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: _redDark.withValues(alpha: 0.15),
        border: Border.all(
            color: _redDark.withValues(alpha: 0.35 + glow * 0.2), width: 1),
        boxShadow: [BoxShadow(
            color: _red.withValues(alpha: glow * 0.1),
            blurRadius: 10)],
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 5, height: 5,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _red,
              boxShadow: [BoxShadow(
                  color: _red.withValues(alpha: 0.5 + glow * 0.3),
                  blurRadius: 6)],
            )),
        const SizedBox(width: 7),
        Text(role.toUpperCase(),
            style: const TextStyle(
                color: _red,
                fontFamily: 'Orbitron',
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 2)),
      ]),
    );
  }
}

class _ExpiryPill extends StatelessWidget {
  final String date;
  const _ExpiryPill({required this.date});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: _surface,
        border: Border.all(color: _rim, width: 1),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.access_time_rounded, color: _ash, size: 11),
        const SizedBox(width: 5),
        Text(date,
            style: const TextStyle(
                color: _ash,
                fontFamily: 'ShareTechMono',
                fontSize: 9.5,
                letterSpacing: 0.5)),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  IMAGE SOURCE SHEET
// ─────────────────────────────────────────────────────────────
class _ImageSourceSheet extends StatelessWidget {
  final VoidCallback onCamera;
  final VoidCallback onGallery;
  const _ImageSourceSheet({required this.onCamera, required this.onGallery});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _plate,
        border: Border(top: BorderSide(color: _rim, width: 1)),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 10),
          Container(width: 36, height: 3,
            decoration: BoxDecoration(
                color: _slate, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 20),
          _SheetTile(
            icon: Icons.camera_alt_rounded,
            label: 'Kamera',
            onTap: onCamera,
          ),
          Container(height: 1, margin: const EdgeInsets.symmetric(horizontal: 16),
              color: _rim),
          _SheetTile(
            icon: Icons.photo_library_rounded,
            label: 'Galeri',
            onTap: onGallery,
          ),
          const SizedBox(height: 16),
        ]),
      ),
    );
  }
}

class _SheetTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _SheetTile({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Container(
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: _surface,
          border: Border.all(color: _rim),
        ),
        child: Icon(icon, color: _red, size: 17),
      ),
      title: Text(label,
          style: const TextStyle(
              color: _snow,
              fontFamily: 'ShareTechMono',
              fontSize: 13,
              letterSpacing: 1)),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  DATA ROW MODEL
// ─────────────────────────────────────────────────────────────
class _DataRow {
  final IconData icon;
  final String label;
  final String value;
  const _DataRow({required this.icon, required this.label, required this.value});
}

// ─────────────────────────────────────────────────────────────
//  HERO STRIPE PAINTER
// ─────────────────────────────────────────────────────────────
class _HeroStripePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()
      ..color = _red.withValues(alpha: 0.025)
      ..strokeWidth = 1;
    const step = 22.0;
    for (double i = -s.height; i < s.width + s.height; i += step) {
      canvas.drawLine(Offset(i, 0), Offset(i + s.height, s.height), p);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

// ─────────────────────────────────────────────────────────────
//  BACKGROUND PAINTER
// ─────────────────────────────────────────────────────────────
class _ProfileBgPainter extends CustomPainter {
  final double t;
  const _ProfileBgPainter({required this.t});

  @override
  void paint(Canvas canvas, Size s) {
    canvas.drawRect(Offset.zero & s, Paint()..color = _void);

    // subtle red radial top-right
    canvas.drawRect(Offset.zero & s, Paint()
      ..shader = RadialGradient(
        colors: [_redDark.withValues(alpha: 0.08), Colors.transparent],
        center: const Alignment(0.8, -0.7),
        radius: 0.8,
      ).createShader(Offset.zero & s));

    // fine grid
    final gp = Paint()
      ..color = _red.withValues(alpha: 0.018)
      ..strokeWidth = 0.4;
    const gs = 30.0;
    for (double x = 0; x < s.width; x += gs) {
      canvas.drawLine(Offset(x, 0), Offset(x, s.height), gp);
    }
    for (double y = 0; y < s.height; y += gs) {
      canvas.drawLine(Offset(0, y), Offset(s.width, y), gp);
    }

    // slow scan line
    final sy = s.height * ((t * 0.3) % 1.0);
    canvas.drawLine(Offset(0, sy), Offset(s.width, sy),
        Paint()
          ..color = _red.withValues(alpha: 0.05)
          ..strokeWidth = 1
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2));

    // vignette
    canvas.drawRect(Offset.zero & s, Paint()
      ..shader = RadialGradient(
        colors: [Colors.transparent, Colors.black.withValues(alpha: 0.55)],
        radius: 1.3,
      ).createShader(Offset.zero & s));
  }

  @override
  bool shouldRepaint(_ProfileBgPainter o) => o.t != t;
}
