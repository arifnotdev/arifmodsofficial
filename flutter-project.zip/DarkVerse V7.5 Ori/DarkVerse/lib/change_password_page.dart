import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const String baseUrl = "http://vionmekss.duckdns.top:10158";

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage>
    with TickerProviderStateMixin {
  // ─── PALETTE (sama persis sama MotivationPage) ─────────────
  static const Color _bg     = Color(0xFF000000);
  static const Color _red    = Color(0xFFFF0040);
  static const Color _redLow = Color(0x22FF0040);
  static const Color _white  = Color(0xFFF2F2F2);
  static const Color _muted  = Color(0xFF4A4A4A);
  static const Color _dim    = Color(0xFF1C1C1C);

  final oldPassCtrl     = TextEditingController();
  final newPassCtrl     = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool _isLoading       = false;
  bool _obscureOld      = true;
  bool _obscureNew      = true;
  bool _obscureConfirm  = true;

  // ─── ANIMASI ───────────────────────────────────────────────
  late AnimationController _glowCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _entryCtrl;

  late Animation<double> _glowAnim;
  late Animation<double> _pulseAnim;
  late Animation<double> _entryAnim;
  late Animation<Offset>  _entrySlide;

  @override
  void initState() {
    super.initState();

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.04, end: 0.13)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    _entryAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _entryCtrl, curve: const Interval(0.0, 0.8, curve: Curves.easeOut)),
    );
    _entrySlide = Tween<Offset>(
      begin: const Offset(0, 0.12),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _pulseCtrl.dispose();
    _entryCtrl.dispose();
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  // ─── API ───────────────────────────────────────────────────
  Future<void> _changePassword() async {
    HapticFeedback.lightImpact();
    final oldPass     = oldPassCtrl.text.trim();
    final newPass     = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("Semua field harus diisi.");
      return;
    }
    if (newPass != confirmPass) {
      _showMessage("Password baru tidak cocok dengan konfirmasi.");
      return;
    }

    setState(() => _isLoading = true);
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _showMessage("Password berhasil diubah!", isSuccess: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showMessage(data['message'] ?? "Gagal mengubah password");
      }
    } catch (e) {
      _showMessage("Koneksi error: $e");
    }
    setState(() => _isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    HapticFeedback.mediumImpact();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0D0D0D),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: isSuccess
                ? _red.withValues(alpha: 0.5)
                : _red.withValues(alpha: 0.25),
            width: 1,
          ),
        ),
        title: Row(
          children: [
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: _red,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _red.withValues(alpha: _pulseAnim.value * 0.6),
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Text(
              isSuccess ? "SUKSES" : "PERINGATAN",
              style: const TextStyle(
                color: _white,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w700,
                fontSize: 13,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: TextStyle(
            color: _white.withValues(alpha: 0.6),
            fontFamily: 'ShareTechMono',
            fontSize: 13,
            height: 1.6,
          ),
        ),
        actions: [
          Center(
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                decoration: BoxDecoration(
                  color: _redLow,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _red.withValues(alpha: 0.4), width: 1),
                ),
                child: const Text(
                  "OK",
                  style: TextStyle(
                    color: _red,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
        ],
      ),
    );
  }

  // ─── INPUT FIELD ───────────────────────────────────────────
  Widget _buildInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required bool obscure,
    required VoidCallback onToggle,
  }) {
    return AnimatedBuilder(
      animation: _entryCtrl,
      builder: (_, child) => FadeTransition(
        opacity: _entryAnim,
        child: SlideTransition(position: _entrySlide, child: child),
      ),
      child: Container(
        height: 58,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: _dim,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _muted.withValues(alpha: 0.3), width: 1),
        ),
        child: TextFormField(
          controller: controller,
          obscureText: obscure,
          style: const TextStyle(
            color: _white,
            fontSize: 15,
            fontFamily: 'ShareTechMono',
          ),
          decoration: InputDecoration(
            labelText: label,
            labelStyle: TextStyle(
              color: _muted,
              fontFamily: 'ShareTechMono',
              fontSize: 12,
              letterSpacing: 1.5,
            ),
            prefixIcon: Icon(icon, color: _red, size: 18),
            suffixIcon: IconButton(
              icon: Icon(
                obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                color: _muted,
                size: 18,
              ),
              onPressed: onToggle,
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 18),
            floatingLabelStyle: TextStyle(
              color: _red.withValues(alpha: 0.7),
              fontFamily: 'ShareTechMono',
              fontSize: 11,
              letterSpacing: 1.5,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _red, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          "CHANGE PASSWORD",
          style: TextStyle(
            color: _white,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w700,
            fontSize: 13,
            letterSpacing: 2,
          ),
        ),
      ),
      body: Stack(
        children: [
          // ── Ambient glow ──────────────────────────────
          AnimatedBuilder(
            animation: _glowAnim,
            builder: (_, __) => Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -0.4),
                  radius: 0.85,
                  colors: [
                    _red.withValues(alpha: _glowAnim.value),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // ── Grid overlay ──────────────────────────────
          Opacity(
            opacity: 0.025,
            child: CustomPaint(
              size: MediaQuery.of(context).size,
              painter: _GridPainter(),
            ),
          ),

          // ── Corner accents ────────────────────────────
          Positioned(top: 8, left: 8,   child: _CornerAccent(isTop: true,  isLeft: true)),
          Positioned(top: 8, right: 8,  child: _CornerAccent(isTop: true,  isLeft: false)),
          Positioned(bottom: 8, left: 8,  child: _CornerAccent(isTop: false, isLeft: true)),
          Positioned(bottom: 8, right: 8, child: _CornerAccent(isTop: false, isLeft: false)),

          // ── Content ───────────────────────────────────
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  const SizedBox(height: 24),

                  // ── Lock icon ──────────────────────
                  FadeTransition(
                    opacity: _entryAnim,
                    child: Column(
                      children: [
                        AnimatedBuilder(
                          animation: _pulseAnim,
                          builder: (_, child) => Container(
                            width: 88,
                            height: 88,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _dim,
                              border: Border.all(
                                color: _red.withValues(alpha: _pulseAnim.value * 0.5),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _red.withValues(alpha: _pulseAnim.value * 0.15),
                                  blurRadius: 24,
                                  spreadRadius: 0,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.lock_reset_rounded,
                              color: _red,
                              size: 36,
                            ),
                          ),
                        ),
                        const SizedBox(height: 18),
                        const Text(
                          "SECURITY UPDATE",
                          style: TextStyle(
                            color: _white,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w700,
                            fontSize: 18,
                            letterSpacing: 3,
                          ),
                        ),
                        const SizedBox(height: 8),
                        // Red line divider
                        _RedLineDivider(),
                        const SizedBox(height: 10),
                        Text(
                          "Masukkan password lama dan baru kamu.",
                          style: TextStyle(
                            color: _muted,
                            fontFamily: 'ShareTechMono',
                            fontSize: 11,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 40),

                  // ── Section label ──────────────────
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "// CREDENTIALS",
                      style: TextStyle(
                        color: _red.withValues(alpha: 0.6),
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ── Inputs ─────────────────────────
                  _buildInput(
                    controller: oldPassCtrl,
                    label: "OLD PASSWORD",
                    icon: Icons.lock_outline_rounded,
                    obscure: _obscureOld,
                    onToggle: () => setState(() => _obscureOld = !_obscureOld),
                  ),
                  _buildInput(
                    controller: newPassCtrl,
                    label: "NEW PASSWORD",
                    icon: Icons.vpn_key_rounded,
                    obscure: _obscureNew,
                    onToggle: () => setState(() => _obscureNew = !_obscureNew),
                  ),
                  _buildInput(
                    controller: confirmPassCtrl,
                    label: "CONFIRM PASSWORD",
                    icon: Icons.enhanced_encryption_rounded,
                    obscure: _obscureConfirm,
                    onToggle: () => setState(() => _obscureConfirm = !_obscureConfirm),
                  ),

                  const SizedBox(height: 32),

                  // ── Button ─────────────────────────
                  FadeTransition(
                    opacity: _entryAnim,
                    child: GestureDetector(
                      onTap: _isLoading ? null : _changePassword,
                      child: AnimatedBuilder(
                        animation: _pulseAnim,
                        builder: (_, child) => Container(
                          width: double.infinity,
                          height: 56,
                          decoration: BoxDecoration(
                            color: _redLow,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: _isLoading
                                  ? _red.withValues(alpha: 0.2)
                                  : _red.withValues(alpha: _pulseAnim.value * 0.6),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _red.withValues(
                                    alpha: _isLoading ? 0.05 : _pulseAnim.value * 0.12),
                                blurRadius: 20,
                                spreadRadius: 0,
                              ),
                            ],
                          ),
                          alignment: Alignment.center,
                          child: _isLoading
                              ? SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: _red.withValues(alpha: 0.7),
                                  ),
                                )
                              : const Text(
                                  "UPDATE PASSWORD",
                                  style: TextStyle(
                                    color: _red,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.w700,
                                    fontSize: 12,
                                    letterSpacing: 2.5,
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),

          // ── Red dot (top left) ────────────────────────
          Positioned(
            top: 48,
            left: 20,
            child: AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  color: _red,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _red.withValues(alpha: _pulseAnim.value * 0.7),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Red line divider ──────────────────────────────────────────
class _RedLineDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 1,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFFFF0040).withValues(alpha: 0.0),
            const Color(0xFFFF0040).withValues(alpha: 0.9),
            const Color(0xFFFF0040).withValues(alpha: 0.0),
          ],
        ),
      ),
    );
  }
}

// ── Corner accent ─────────────────────────────────────────────
class _CornerAccent extends StatelessWidget {
  final bool isTop;
  final bool isLeft;
  const _CornerAccent({required this.isTop, required this.isLeft});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(20, 20),
      painter: _CornerPainter(
        isTop: isTop,
        isLeft: isLeft,
        color: const Color(0xFFFF0040).withValues(alpha: 0.2),
      ),
    );
  }
}

class _CornerPainter extends CustomPainter {
  final bool isTop, isLeft;
  final Color color;
  _CornerPainter({required this.isTop, required this.isLeft, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    final x  = isLeft ? 0.0 : size.width;
    final y  = isTop  ? 0.0 : size.height;
    final dx = isLeft ?  size.width * 0.5 : -size.width * 0.5;
    final dy = isTop  ?  size.height * 0.5 : -size.height * 0.5;
    canvas.drawLine(Offset(x, y), Offset(x + dx, y), paint);
    canvas.drawLine(Offset(x, y), Offset(x, y + dy), paint);
  }

  @override
  bool shouldRepaint(_CornerPainter old) => false;
}

// ── Grid painter ──────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF4A4A4A)
      ..strokeWidth = 0.5;
    const spacing = 40.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_GridPainter old) => false;
}